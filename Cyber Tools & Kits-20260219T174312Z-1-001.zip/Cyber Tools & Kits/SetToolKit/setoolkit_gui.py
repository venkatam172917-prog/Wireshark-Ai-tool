#!/usr/bin/env python3
"""
Social Engineering Toolkit (SET) GUI - A graphical interface for SET
Author: Claude
License: MIT
"""

import subprocess
import sys
import os
import threading
import time
from pathlib import Path

# Auto-install dependencies
def install_dependencies():
    """Install required packages if not already installed"""
    
    # Check if setoolkit is installed
    try:
        result = subprocess.run(['which', 'setoolkit'], capture_output=True, check=True, text=True)
        print("✓ Social Engineering Toolkit is installed")
        print(f"Location: {result.stdout.strip()}")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("✗ Social Engineering Toolkit is not installed")
        print("Please install SET first:")
        print("  sudo apt-get update && sudo apt-get install set -y")
        print("  OR")
        print("  git clone https://github.com/trustedsec/social-engineer-toolkit/ set/")
        print("  cd set && sudo python setup.py install")
        sys.exit(1)

# Run dependency check
install_dependencies()

import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox

class SETGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Social Engineering Toolkit (SET) GUI")
        self.root.geometry("1100x800")
        self.root.configure(bg='#2b2b2b')
        
        # Variables
        self.attack_vector_var = tk.StringVar(value='spear_phishing')
        self.payload_type_var = tk.StringVar(value='meterpreter')
        self.lhost_var = tk.StringVar()
        self.lport_var = tk.StringVar(value='443')
        self.email_target_var = tk.StringVar()
        self.email_subject_var = tk.StringVar()
        self.email_from_var = tk.StringVar()
        self.smtp_server_var = tk.StringVar()
        self.smtp_port_var = tk.StringVar(value='25')
        self.template_var = tk.StringVar(value='custom')
        self.clone_url_var = tk.StringVar()
        self.payload_file_var = tk.StringVar()
        self.encoding_var = tk.StringVar(value='none')
        self.arduino_type_var = tk.StringVar(value='teensy')
        self.qr_data_var = tk.StringVar()
        
        self.is_running = False
        self.process = None
        
        self.create_widgets()
        self.get_local_ip()
        
    def create_widgets(self):
        # Main container with scrollbar
        main_canvas = tk.Canvas(self.root, bg='#2b2b2b', highlightthickness=0)
        scrollbar = tk.Scrollbar(self.root, orient="vertical", command=main_canvas.yview)
        scrollable_frame = tk.Frame(main_canvas, bg='#2b2b2b')
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: main_canvas.configure(scrollregion=main_canvas.bbox("all"))
        )
        
        main_canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=scrollbar.set)
        
        main_canvas.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        scrollbar.pack(side="right", fill="y")
        
        # Title
        title = tk.Label(scrollable_frame, text="🎯 Social Engineering Toolkit (SET)", 
                        font=('Arial', 18, 'bold'), bg='#2b2b2b', fg='#ff6b6b')
        title.pack(pady=(0, 10))
        
        # Warning label
        warning = tk.Label(scrollable_frame, 
                          text="⚠️  CRITICAL: For authorized security testing ONLY - Unauthorized use is a SERIOUS CRIME",
                          font=('Arial', 10, 'bold'), bg='#2b2b2b', fg='#ff0000')
        warning.pack(pady=(0, 15))
        
        # Attack Vector Selection
        vector_frame = tk.LabelFrame(scrollable_frame, text="1. Select Attack Vector", 
                                    bg='#3b3b3b', fg='#ffffff', 
                                    font=('Arial', 11, 'bold'))
        vector_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        vectors = [
            ("📧 Spear-Phishing Attack", "spear_phishing", "Send targeted phishing emails with malicious payloads"),
            ("🌐 Website Attack Vectors", "website_attack", "Clone websites, credential harvester, tabnabbing"),
            ("🔌 Infectious Media Generator", "infectious_media", "Create autorun USB/CD malware"),
            ("📱 QRCode Generator", "qrcode", "Generate malicious QR codes"),
            ("📨 Mass Mailer Attack", "mass_mailer", "Send mass phishing emails"),
            ("🎭 SMS Spoofing Attack", "sms_spoof", "Send spoofed SMS messages"),
            ("📞 Wireless Access Point", "wireless_ap", "Create fake WiFi access point"),
            ("💾 Payload & Listener", "payload_listener", "Generate payloads and setup listeners"),
        ]
        
        row = 0
        for text, value, desc in vectors:
            rb = tk.Radiobutton(vector_frame, text=text, variable=self.attack_vector_var, 
                              value=value, bg='#3b3b3b', fg='#ffffff',
                              selectcolor='#4b4b4b', activebackground='#3b3b3b',
                              activeforeground='#ffffff', font=('Arial', 10),
                              command=self.update_attack_options)
            rb.grid(row=row, column=0, sticky='w', padx=10, pady=3)
            
            desc_label = tk.Label(vector_frame, text=f"   → {desc}", 
                                 bg='#3b3b3b', fg='#aaaaaa', font=('Arial', 8))
            desc_label.grid(row=row, column=1, sticky='w', padx=5, pady=3)
            row += 1
        
        # Configuration Frame
        self.config_frame = tk.LabelFrame(scrollable_frame, text="2. Attack Configuration", 
                                         bg='#3b3b3b', fg='#ffffff', 
                                         font=('Arial', 11, 'bold'))
        self.config_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        # Network Configuration (Common)
        self.network_frame = tk.LabelFrame(self.config_frame, text="Network Settings", 
                                          bg='#3b3b3b', fg='#00ff00')
        self.network_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(self.network_frame, text="Local IP (LHOST):", bg='#3b3b3b', fg='#ffffff').grid(
            row=0, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(self.network_frame, textvariable=self.lhost_var, width=20, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=0, column=1, sticky='w', padx=10, pady=5)
        tk.Button(self.network_frame, text="Auto-Detect", command=self.get_local_ip,
                 bg='#5b5b5b', fg='#ffffff', relief=tk.FLAT).grid(
            row=0, column=2, padx=5, pady=5)
        
        tk.Label(self.network_frame, text="Local Port (LPORT):", bg='#3b3b3b', fg='#ffffff').grid(
            row=0, column=3, sticky='w', padx=10, pady=5)
        tk.Entry(self.network_frame, textvariable=self.lport_var, width=10, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=0, column=4, sticky='w', padx=10, pady=5)
        
        # Spear Phishing Frame
        self.phishing_frame = tk.LabelFrame(self.config_frame, text="Spear-Phishing Configuration", 
                                           bg='#3b3b3b', fg='#00ff00')
        self.phishing_frame.pack(fill=tk.X, padx=10, pady=5)
        
        row = 0
        tk.Label(self.phishing_frame, text="Target Email:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(self.phishing_frame, textvariable=self.email_target_var, width=40, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, columnspan=3, sticky='ew', padx=10, pady=5)
        
        row += 1
        tk.Label(self.phishing_frame, text="From Email:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(self.phishing_frame, textvariable=self.email_from_var, width=40, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, columnspan=3, sticky='ew', padx=10, pady=5)
        
        row += 1
        tk.Label(self.phishing_frame, text="Subject:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(self.phishing_frame, textvariable=self.email_subject_var, width=40, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, columnspan=3, sticky='ew', padx=10, pady=5)
        
        row += 1
        tk.Label(self.phishing_frame, text="SMTP Server:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(self.phishing_frame, textvariable=self.smtp_server_var, width=25, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, sticky='w', padx=10, pady=5)
        
        tk.Label(self.phishing_frame, text="Port:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=2, sticky='w', padx=10, pady=5)
        tk.Entry(self.phishing_frame, textvariable=self.smtp_port_var, width=10, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=3, sticky='w', padx=10, pady=5)
        
        row += 1
        tk.Label(self.phishing_frame, text="Email Template:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        templates = ['custom', 'google_docs', 'microsoft_office', 'dropbox', 
                    'linkedin', 'facebook', 'twitter']
        ttk.Combobox(self.phishing_frame, textvariable=self.template_var, 
                    values=templates, width=20, state='readonly').grid(
            row=row, column=1, sticky='w', padx=10, pady=5)
        
        self.phishing_frame.columnconfigure(1, weight=1)
        
        # Website Attack Frame
        self.website_frame = tk.LabelFrame(self.config_frame, text="Website Attack Configuration", 
                                          bg='#3b3b3b', fg='#00ff00')
        self.website_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(self.website_frame, text="URL to Clone:", bg='#3b3b3b', fg='#ffffff').grid(
            row=0, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(self.website_frame, textvariable=self.clone_url_var, width=50, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=0, column=1, sticky='ew', padx=10, pady=5)
        
        self.website_frame.columnconfigure(1, weight=1)
        
        # Payload Configuration Frame
        self.payload_frame = tk.LabelFrame(self.config_frame, text="Payload Configuration", 
                                          bg='#3b3b3b', fg='#00ff00')
        self.payload_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(self.payload_frame, text="Payload Type:", bg='#3b3b3b', fg='#ffffff').grid(
            row=0, column=0, sticky='w', padx=10, pady=5)
        payloads = ['meterpreter', 'shell', 'vnc', 'powershell', 'python', 'custom']
        ttk.Combobox(self.payload_frame, textvariable=self.payload_type_var, 
                    values=payloads, width=20, state='readonly').grid(
            row=0, column=1, sticky='w', padx=10, pady=5)
        
        tk.Label(self.payload_frame, text="Encoding:", bg='#3b3b3b', fg='#ffffff').grid(
            row=0, column=2, sticky='w', padx=10, pady=5)
        encodings = ['none', 'shikata_ga_nai', 'fnstenv_mov', 'jmp_call_additive', 
                    'nonalpha', 'unicode_mixed']
        ttk.Combobox(self.payload_frame, textvariable=self.encoding_var, 
                    values=encodings, width=20, state='readonly').grid(
            row=0, column=3, sticky='w', padx=10, pady=5)
        
        tk.Label(self.payload_frame, text="Custom Payload:", bg='#3b3b3b', fg='#ffffff').grid(
            row=1, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(self.payload_frame, textvariable=self.payload_file_var, width=40, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=1, column=1, columnspan=2, sticky='ew', padx=10, pady=5)
        tk.Button(self.payload_frame, text="Browse", command=self.browse_payload,
                 bg='#5b5b5b', fg='#ffffff', relief=tk.FLAT).grid(
            row=1, column=3, padx=10, pady=5)
        
        # QR Code Frame
        self.qr_frame = tk.LabelFrame(self.config_frame, text="QR Code Configuration", 
                                     bg='#3b3b3b', fg='#00ff00')
        self.qr_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(self.qr_frame, text="QR Code Data/URL:", bg='#3b3b3b', fg='#ffffff').grid(
            row=0, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(self.qr_frame, textvariable=self.qr_data_var, width=60, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=0, column=1, sticky='ew', padx=10, pady=5)
        
        self.qr_frame.columnconfigure(1, weight=1)
        
        # Arduino/Teensy Frame
        self.arduino_frame = tk.LabelFrame(self.config_frame, text="USB HID Attack Configuration", 
                                          bg='#3b3b3b', fg='#00ff00')
        self.arduino_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(self.arduino_frame, text="Device Type:", bg='#3b3b3b', fg='#ffffff').grid(
            row=0, column=0, sticky='w', padx=10, pady=5)
        devices = ['teensy', 'arduino', 'usb_rubber_ducky']
        ttk.Combobox(self.arduino_frame, textvariable=self.arduino_type_var, 
                    values=devices, width=20, state='readonly').grid(
            row=0, column=1, sticky='w', padx=10, pady=5)
        
        # Presets Frame
        presets_frame = tk.LabelFrame(scrollable_frame, text="3. Quick Attack Presets", 
                                     bg='#3b3b3b', fg='#ffffff', 
                                     font=('Arial', 11, 'bold'))
        presets_frame.pack(fill=tk.X, padx=5, pady=5)
        
        preset_buttons = tk.Frame(presets_frame, bg='#3b3b3b')
        preset_buttons.pack(pady=10)
        
        presets = [
            ("📧 Gmail Phishing", self.preset_gmail),
            ("🏢 Office 365 Phishing", self.preset_office365),
            ("💼 LinkedIn Phishing", self.preset_linkedin),
            ("🌐 Credential Harvester", self.preset_harvester),
            ("🔌 USB Payload", self.preset_usb),
            ("📱 Android Payload", self.preset_android),
        ]
        
        for i, (text, command) in enumerate(presets):
            tk.Button(preset_buttons, text=text, command=command,
                     bg='#5b5b5b', fg='#ffffff', font=('Arial', 9),
                     relief=tk.FLAT, padx=10, pady=5).grid(
                row=i//3, column=i%3, padx=5, pady=5)
        
        # Control buttons
        button_frame = tk.Frame(scrollable_frame, bg='#2b2b2b')
        button_frame.pack(fill=tk.X, pady=10)
        
        self.start_button = tk.Button(button_frame, text="🚀 Launch Attack", 
                                      command=self.launch_attack,
                                      bg='#ff6b6b', fg='#ffffff', 
                                      font=('Arial', 12, 'bold'),
                                      relief=tk.FLAT, padx=25, pady=10,
                                      cursor='hand2')
        self.start_button.pack(side=tk.LEFT, padx=5)
        
        self.stop_button = tk.Button(button_frame, text="⬛ Stop Attack", 
                                     command=self.stop_attack,
                                     bg='#aa0000', fg='#ffffff', 
                                     font=('Arial', 12, 'bold'),
                                     relief=tk.FLAT, padx=25, pady=10,
                                     cursor='hand2', state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="📋 Generate Report", 
                 command=self.generate_report,
                 bg='#5b5b5b', fg='#ffffff', 
                 font=('Arial', 11),
                 relief=tk.FLAT, padx=20, pady=10,
                 cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="🗑 Clear Output", 
                 command=self.clear_output,
                 bg='#5b5b5b', fg='#ffffff', 
                 font=('Arial', 11),
                 relief=tk.FLAT, padx=20, pady=10,
                 cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        # Output frame
        output_frame = tk.LabelFrame(scrollable_frame, text="4. Attack Output & Logs", 
                                    bg='#3b3b3b', fg='#ffffff', 
                                    font=('Arial', 11, 'bold'))
        output_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.output_text = scrolledtext.ScrolledText(output_frame, 
                                                     bg='#1e1e1e', 
                                                     fg='#00ff00',
                                                     font=('Courier', 9),
                                                     insertbackground='white',
                                                     height=15)
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready - Select attack vector and configure options")
        status_bar = tk.Label(scrollable_frame, textvariable=self.status_var, 
                            bg='#1e1e1e', fg='#00ff00', 
                            relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(fill=tk.X, pady=(5, 0))
        
        # Initial update
        self.update_attack_options()
    
    def update_attack_options(self):
        """Show/hide frames based on selected attack vector"""
        vector = self.attack_vector_var.get()
        
        # Hide all frames
        self.phishing_frame.pack_forget()
        self.website_frame.pack_forget()
        self.payload_frame.pack_forget()
        self.qr_frame.pack_forget()
        self.arduino_frame.pack_forget()
        
        # Show relevant frames
        if vector == 'spear_phishing':
            self.phishing_frame.pack(fill=tk.X, padx=10, pady=5)
            self.payload_frame.pack(fill=tk.X, padx=10, pady=5)
        elif vector == 'website_attack':
            self.website_frame.pack(fill=tk.X, padx=10, pady=5)
        elif vector == 'infectious_media':
            self.payload_frame.pack(fill=tk.X, padx=10, pady=5)
            self.arduino_frame.pack(fill=tk.X, padx=10, pady=5)
        elif vector == 'qrcode':
            self.qr_frame.pack(fill=tk.X, padx=10, pady=5)
        elif vector == 'mass_mailer':
            self.phishing_frame.pack(fill=tk.X, padx=10, pady=5)
            self.payload_frame.pack(fill=tk.X, padx=10, pady=5)
        elif vector == 'payload_listener':
            self.payload_frame.pack(fill=tk.X, padx=10, pady=5)
    
    def get_local_ip(self):
        """Auto-detect local IP address"""
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            self.lhost_var.set(ip)
            self.log(f"✓ Auto-detected local IP: {ip}", '#00ff00')
        except Exception as e:
            self.log(f"✗ Could not auto-detect IP: {str(e)}", '#ff6b6b')
    
    def browse_payload(self):
        filename = filedialog.askopenfilename(
            title="Select Payload File",
            filetypes=[("Executable", "*.exe"), ("All files", "*.*")]
        )
        if filename:
            self.payload_file_var.set(filename)
    
    def clear_output(self):
        self.output_text.delete(1.0, tk.END)
    
    def log(self, message, color='#00ff00'):
        self.output_text.insert(tk.END, message + '\n')
        self.output_text.see(tk.END)
        self.output_text.update()
    
    # Preset configurations
    def preset_gmail(self):
        self.attack_vector_var.set('spear_phishing')
        self.email_from_var.set('noreply@accounts-google.com')
        self.email_subject_var.set('Security Alert: Unusual Activity Detected')
        self.template_var.set('google_docs')
        self.update_attack_options()
        self.log("✓ Gmail phishing preset loaded", '#ffff00')
    
    def preset_office365(self):
        self.attack_vector_var.set('spear_phishing')
        self.email_from_var.set('noreply@microsoft.com')
        self.email_subject_var.set('Action Required: Verify Your Account')
        self.template_var.set('microsoft_office')
        self.update_attack_options()
        self.log("✓ Office 365 phishing preset loaded", '#ffff00')
    
    def preset_linkedin(self):
        self.attack_vector_var.set('spear_phishing')
        self.email_from_var.set('notifications@linkedin.com')
        self.email_subject_var.set('You have new connection requests')
        self.template_var.set('linkedin')
        self.update_attack_options()
        self.log("✓ LinkedIn phishing preset loaded", '#ffff00')
    
    def preset_harvester(self):
        self.attack_vector_var.set('website_attack')
        self.update_attack_options()
        self.log("✓ Credential harvester preset loaded", '#ffff00')
    
    def preset_usb(self):
        self.attack_vector_var.set('infectious_media')
        self.arduino_type_var.set('teensy')
        self.update_attack_options()
        self.log("✓ USB payload preset loaded", '#ffff00')
    
    def preset_android(self):
        self.attack_vector_var.set('payload_listener')
        self.payload_type_var.set('meterpreter')
        self.lport_var.set('4444')
        self.update_attack_options()
        self.log("✓ Android payload preset loaded", '#ffff00')
    
    def validate_inputs(self):
        """Validate required inputs based on attack vector"""
        vector = self.attack_vector_var.get()
        
        if not self.lhost_var.get():
            messagebox.showerror("Error", "Please set local IP address (LHOST)")
            return False
        
        if vector == 'spear_phishing' or vector == 'mass_mailer':
            if not self.email_target_var.get():
                messagebox.showerror("Error", "Please enter target email address")
                return False
            if not self.email_from_var.get():
                messagebox.showerror("Error", "Please enter from email address")
                return False
        
        if vector == 'website_attack':
            if not self.clone_url_var.get():
                messagebox.showerror("Error", "Please enter URL to clone")
                return False
        
        if vector == 'qrcode':
            if not self.qr_data_var.get():
                messagebox.showerror("Error", "Please enter QR code data")
                return False
        
        return True
    
    def build_command(self):
        """Build SET command based on configuration"""
        # Note: SET is interactive, so we'll create a wrapper script
        vector = self.attack_vector_var.get()
        
        # This is a simplified example - actual implementation would need
        # to handle SET's interactive menu system
        self.log("=" * 70)
        self.log("⚠️  NOTE: SET is highly interactive", '#ffff00')
        self.log("This GUI provides configuration assistance.", '#ffff00')
        self.log("For full functionality, run: sudo setoolkit", '#ffff00')
        self.log("=" * 70)
        
        config = {
            'attack_vector': vector,
            'lhost': self.lhost_var.get(),
            'lport': self.lport_var.get(),
            'payload': self.payload_type_var.get(),
            'encoding': self.encoding_var.get()
        }
        
        if vector == 'spear_phishing':
            config.update({
                'target_email': self.email_target_var.get(),
                'from_email': self.email_from_var.get(),
                'subject': self.email_subject_var.get(),
                'smtp_server': self.smtp_server_var.get(),
                'smtp_port': self.smtp_port_var.get(),
                'template': self.template_var.get()
            })
        elif vector == 'website_attack':
            config['clone_url'] = self.clone_url_var.get()
        elif vector == 'qrcode':
            config['qr_data'] = self.qr_data_var.get()
        
        return config
    
    def generate_attack_script(self, config):
        """Generate a Python script to automate SET"""
        script = f"""#!/usr/bin/env python3
# Auto-generated SET attack script
# Generated by SET GUI

import subprocess
import time

def run_set_attack():
    print("[*] Starting Social Engineering Toolkit attack...")
    print("[*] Attack Vector: {config['attack_vector']}")
    print("[*] LHOST: {config['lhost']}")
    print("[*] LPORT: {config['lport']}")
    
    # Note: This is a template - customize based on your specific attack
    # SET requires interactive input, so full automation may require expect or pexpect
    
    try:
        # Launch setoolkit
        # You'll need to interact with the menus
        subprocess.run(['sudo', 'setoolkit'])
    except KeyboardInterrupt:
        print("\\n[!] Attack stopped by user")
    except Exception as e:
        print(f"[!] Error: {{e}}")

if __name__ == "__main__":
    run_set_attack()
"""
        return script
    
    def launch_attack(self):
        """Launch the social engineering attack"""
        if not self.validate_inputs():
            return
        
        # Confirmation dialog
        result = messagebox.askyesnocancel(
            "⚠️  LEGAL WARNING",
            "You are about to launch a social engineering attack.\n\n"
            "This action is ILLEGAL without explicit written authorization.\n\n"
            "Do you have proper authorization to proceed?\n\n"
            "YES = I have written authorization\n"
            "NO = Cancel attack\n"
            "CANCEL = Review configuration"
        )
        
        if result is None:  # Cancel
            return
        
        if not result:  # No
            messagebox.showwarning("Attack Cancelled", "Attack cancelled. Please obtain proper authorization.")
            return
        
        self.is_running = True
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.status_var.set("Attack configured - Ready to execute")
        
        config = self.build_command()
        
        self.log("=" * 70)
        self.log("🎯 ATTACK CONFIGURATION", '#ffff00')
        self.log("=" * 70)
        
        for key, value in config.items():
            if value and key not in ['smtp_server', 'smtp_port']:  # Don't log sensitive data
                self.log(f"{key.upper()}: {value}", '#00ffff')
        
        self.log("=" * 70)
        
        # Generate attack script
        script = self.generate_attack_script(config)
        script_path = '/tmp/set_attack_script.py'
        
        try:
            with open(script_path, 'w') as f:
                f.write(script)
            os.chmod(script_path, 0o755)
            
            self.log(f"✓ Attack script generated: {script_path}", '#00ff00')
            self.log("=" * 70)
            self.log("📋 NEXT STEPS:", '#ffff00')
            self.log("1. Review the generated script", '#ffffff')
            self.log("2. Run: sudo python3 /tmp/set_attack_script.py", '#ffffff')
            self.log("3. Or run: sudo setoolkit (for interactive mode)", '#ffffff')
            self.log("=" * 70)
            self.log("⚠️  Remember: Only use with proper authorization!", '#ff6b6b')
            self.log("=" * 70)
            
            # Ask if user wants to open terminal with setoolkit
            open_terminal = messagebox.askyesno(
                "Launch SET",
                "Would you like to open setoolkit in a new terminal?\n\n"
                "(You will need to manually navigate the SET menus)"
            )
            
            if open_terminal:
                # Try to open terminal with setoolkit
                terminal_commands = [
                    ['gnome-terminal', '--', 'sudo', 'setoolkit'],
                    ['xterm', '-e', 'sudo setoolkit'],
                    ['konsole', '-e', 'sudo setoolkit'],
                    ['terminator', '-e', 'sudo setoolkit'],
                ]
                
                launched = False
                for cmd in terminal_commands:
                    try:
                        subprocess.Popen(cmd)
                        self.log(f"✓ Launched terminal: {cmd[0]}", '#00ff00')
                        launched = True
                        break
                    except FileNotFoundError:
                        continue
                
                if not launched:
                    self.log("✗ Could not find terminal emulator", '#ff6b6b')
                    self.log("Please run manually: sudo setoolkit", '#ffff00')
            
        except Exception as e:
            self.log(f"✗ Error: {str(e)}", '#ff6b6b')
        
        finally:
            self.is_running = False
            self.start_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)
    
    def stop_attack(self):
        """Stop the current attack"""
        if self.process:
            self.process.terminate()
            self.log("⬛ Attack stopped by user", '#ffff00')
        
        self.is_running = False
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.status_var.set("Attack stopped")
    
    def generate_report(self):
        """Generate attack report"""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        report_file = f"/tmp/set_report_{timestamp}.txt"
        
        try:
            config = self.build_command()
            
            with open(report_file, 'w') as f:
                f.write("=" * 70 + "\n")
                f.write("SOCIAL ENGINEERING TOOLKIT - ATTACK REPORT\n")
                f.write("=" * 70 + "\n\n")
                f.write(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                f.write("CONFIGURATION:\n")
                f.write("-" * 70 + "\n")
                
                for key, value in config.items():
                    if value:
                        f.write(f"{key.upper()}: {value}\n")
                
                f.write("\n" + "=" * 70 + "\n")
                f.write("OUTPUT LOG:\n")
                f.write("=" * 70 + "\n\n")
                f.write(self.output_text.get(1.0, tk.END))
            
            self.log(f"✓ Report generated: {report_file}", '#00ff00')
            messagebox.showinfo("Report Generated", f"Report saved to:\n{report_file}")
            
        except Exception as e:
            self.log(f"✗ Error generating report: {str(e)}", '#ff6b6b')

def main():
    root = tk.Tk()
    app = SETGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
