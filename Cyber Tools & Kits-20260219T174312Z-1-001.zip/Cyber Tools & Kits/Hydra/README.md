# Hydra GUI - Password Bruteforcing Tool Interface

A professional graphical user interface for THC-Hydra, the popular network login password cracker.

## ⚠️ Legal Warning

**FOR AUTHORIZED PENETRATION TESTING AND SECURITY RESEARCH ONLY**

Unauthorized access to computer systems is illegal. This tool should only be used:
- On systems you own
- On systems you have explicit written permission to test
- In authorized penetration testing engagements
- For educational purposes in controlled environments

Misuse of this tool may result in criminal prosecution.

## Features

- 🎨 Clean, modern GUI interface
- 🔧 Support for multiple protocols (SSH, FTP, HTTP, RDP, MySQL, etc.)
- 📁 Single credential or wordlist attacks
- ⚙️ Configurable threads and timeout settings
- 📊 Real-time output display
- 🛑 Start/Stop controls
- 🎯 Easy target and protocol selection

## Prerequisites

### Install Hydra

On Kali Linux or Debian/Ubuntu:
```bash
sudo apt-get update
sudo apt-get install hydra -y
```

On other systems, visit: https://github.com/vanhauser-thc/thc-hydra

### Python Requirements

The script automatically checks for dependencies. You need Python 3.6+:
```bash
python3 --version
```

Tkinter comes pre-installed with most Python distributions. If not:
```bash
sudo apt-get install python3-tk
```

## Installation

1. Download the script:
```bash
wget https://your-server/hydra_gui.py
# or
git clone <repository>
cd hydra-gui
```

2. Make it executable:
```bash
chmod +x hydra_gui.py
```

## Usage

### Launch the GUI

```bash
python3 hydra_gui.py
```

or

```bash
./hydra_gui.py
```

### Configuration Options

1. **Target IP/Host**: Enter the target system's IP address or hostname
2. **Protocol**: Select from dropdown (SSH, FTP, HTTP, RDP, etc.)
3. **Port**: Optional - specify if using non-standard port
4. **Username**: Single username (or use user list)
5. **Password**: Single password (or use password list)
6. **User List File**: Path to file containing usernames (one per line)
7. **Password List File**: Path to file containing passwords (one per line)
8. **Threads**: Number of parallel connections (default: 4)
9. **Timeout**: Connection timeout in seconds (default: 30)
10. **Verbose**: Show detailed output during attack

### Example Usage Scenarios

#### Single Credential Test
- Target: 192.168.1.100
- Protocol: ssh
- Username: admin
- Password: password123
- Click "Start Attack"

#### Dictionary Attack
- Target: 10.0.0.50
- Protocol: ftp
- User List: /usr/share/wordlists/usernames.txt
- Password List: /usr/share/wordlists/rockyou.txt
- Threads: 16
- Click "Start Attack"

#### Web Form Attack
- Target: example.com
- Protocol: http-post-form
- Username: admin
- Password List: /path/to/passwords.txt
- Click "Start Attack"

## Common Wordlists

Kali Linux includes several wordlists in `/usr/share/wordlists/`:

```bash
# Unzip rockyou (most popular password list)
sudo gunzip /usr/share/wordlists/rockyou.txt.gz

# Common locations
/usr/share/wordlists/rockyou.txt
/usr/share/wordlists/dirb/
/usr/share/wordlists/dirbuster/
/usr/share/seclists/
```

## Supported Protocols

- SSH
- FTP
- HTTP/HTTPS
- HTTP-GET
- HTTP-POST
- SMTP
- MySQL
- PostgreSQL
- RDP
- VNC
- Telnet
- And many more...

## Tips for Effective Use

1. **Start Small**: Test with a small wordlist first to verify configuration
2. **Adjust Threads**: More threads = faster, but may trigger IDS/IPS
3. **Use Timeout**: Set appropriate timeout based on network conditions
4. **Verbose Mode**: Enable for troubleshooting, disable for speed
5. **Legal Authorization**: ALWAYS get written permission first

## Troubleshooting

### Hydra not found
```bash
sudo apt-get install hydra
```

### Permission denied
```bash
chmod +x hydra_gui.py
```

### Tkinter import error
```bash
sudo apt-get install python3-tk
```

### Connection refused
- Check if target service is running
- Verify firewall rules
- Confirm network connectivity

## Security Best Practices

When conducting authorized penetration tests:

1. **Get Written Authorization**: Document approval before testing
2. **Define Scope**: Clearly identify what systems can be tested
3. **Set Time Windows**: Conduct tests during approved timeframes
4. **Monitor Impact**: Watch for service degradation
5. **Document Findings**: Keep detailed logs of all activities
6. **Report Responsibly**: Disclose findings through proper channels

## License

MIT License - See LICENSE file for details

## Disclaimer

The creators of this tool are not responsible for any misuse or damage caused by this program. Users are solely responsible for their actions and must comply with all applicable laws and regulations.

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues.

## Support

For issues and questions:
- Check Hydra documentation: https://github.com/vanhauser-thc/thc-hydra
- Review Kali Linux tools documentation
- Consult penetration testing communities

---

**Remember: With great power comes great responsibility. Use ethically and legally.**
