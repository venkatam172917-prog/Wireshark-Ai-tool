# John the Ripper GUI - Password Cracking Tool Interface

A professional graphical user interface for John the Ripper, the legendary password cracking tool.

## ⚠️ Legal Warning

**FOR AUTHORIZED SECURITY TESTING AND PASSWORD RECOVERY ONLY**

This tool should only be used for:
- Recovering your own lost passwords
- Authorized penetration testing with written permission
- Security auditing of systems you own or have explicit authorization to test
- Educational purposes in controlled environments

Unauthorized password cracking is illegal and unethical. Misuse may result in criminal prosecution.

## Features

- 🎨 Modern, intuitive GUI interface
- 🔧 Multiple attack modes (Wordlist, Incremental, Single Crack, Mask)
- 📁 Support for numerous hash formats (MD5, SHA, NTLM, bcrypt, etc.)
- ⚙️ Customizable rules and session management
- 📊 Real-time statistics and progress monitoring
- 🔍 Built-in cracked password viewer
- 💾 Session save/restore functionality
- 🎯 Multi-threaded cracking support

## Prerequisites

### Install John the Ripper

On Kali Linux or Debian/Ubuntu:
```bash
sudo apt-get update
sudo apt-get install john -y
```

For enhanced version (Jumbo):
```bash
sudo apt-get install john-data
```

On other systems, visit: https://www.openwall.com/john/

### Python Requirements

Python 3.6+ with tkinter:
```bash
python3 --version
sudo apt-get install python3-tk
```

## Installation

1. Download the script:
```bash
wget https://your-server/john_gui.py
# or copy the file directly
```

2. Make it executable:
```bash
chmod +x john_gui.py
```

## Usage

### Launch the GUI

```bash
python3 john_gui.py
```

or

```bash
./john_gui.py
```

### Attack Modes

#### 1. Wordlist Attack
Uses a dictionary file to attempt password cracking.

**Configuration:**
- Select "Wordlist" mode
- Choose hash file (containing password hashes)
- Select wordlist file (e.g., rockyou.txt)
- Optionally select rules (best64, single, wordlist, etc.)
- Click "Start Cracking"

**Example:**
```
Hash File: /path/to/hashes.txt
Mode: Wordlist
Wordlist: /usr/share/wordlists/rockyou.txt
Rules: best64
Format: auto
```

#### 2. Incremental Mode
Brute-force attack trying all possible combinations.

**Configuration:**
- Select "Incremental" mode
- Choose incremental mode (ASCII, Alnum, Alpha, Digits, etc.)
- Select hash file
- Click "Start Cracking"

**Incremental Modes:**
- **ASCII**: All printable ASCII characters
- **Alnum**: Alphanumeric characters only
- **Alpha**: Letters only
- **Digits**: Numbers only
- **LowerNum**: Lowercase + numbers
- **UpperNum**: Uppercase + numbers

#### 3. Single Crack Mode
Uses username and GECOS information to generate password candidates.

**Configuration:**
- Select "Single Crack" mode
- Hash file must contain username:hash format
- Click "Start Cracking"

#### 4. Mask Attack
Pattern-based attack using placeholders.

**Configuration:**
- Select "Mask" mode
- Enter mask pattern (e.g., ?u?l?l?l?d?d?d?d)
- Click "Start Cracking"

**Mask Characters:**
- `?l` = lowercase letter
- `?u` = uppercase letter
- `?d` = digit
- `?s` = special character
- `?a` = any printable character

**Example Masks:**
- `?u?l?l?l?d?d` = Password99
- `?d?d?d?d` = 1234
- `Admin?d?d?d?d` = Admin2024

### Hash Formats

Common formats supported:
- **MD5**: raw-md5, md5crypt
- **SHA**: raw-sha1, raw-sha256, raw-sha512
- **Windows**: LM, NTLM
- **Unix**: des, bcrypt
- **Application**: zip, rar, pdf
- **Database**: mysql-sha1, mssql, postgres
- **Network**: krb5

Use "List Formats" button to see all available formats.

### Quick Actions

1. **Show Statistics**: Display current session progress and statistics
2. **Show Cracked**: View all successfully cracked passwords
3. **List Formats**: Display all supported hash formats
4. **Restore Session**: Continue a previously interrupted session

### Session Management

Sessions allow you to:
- Save progress automatically
- Resume interrupted cracking sessions
- Run multiple sessions simultaneously

**To restore a session:**
1. Enter the session name (default: "default")
2. Click "Restore Session"
3. Confirm restoration

## Hash File Format

### Simple Format
```
5f4dcc3b5aa765d61d8327deb882cf99
098f6bcd4621d373cade4e832627b4f6
```

### With Username (for Single mode)
```
admin:5f4dcc3b5aa765d61d8327deb882cf99
user:098f6bcd4621d373cade4e832627b4f6
```

### Extracting Hashes

#### From /etc/shadow (Linux)
```bash
sudo unshadow /etc/passwd /etc/shadow > mypasswords.txt
```

#### From Windows SAM
```bash
samdump2 SYSTEM SAM > windows_hashes.txt
```

## Common Wordlists

### Kali Linux Wordlists
```bash
# Unzip rockyou (most popular)
sudo gunzip /usr/share/wordlists/rockyou.txt.gz

# Common locations
/usr/share/wordlists/rockyou.txt
/usr/share/wordlists/fasttrack.txt
/usr/share/seclists/Passwords/
```

### Creating Custom Wordlists
```bash
# Generate from text
john --wordlist=source.txt --stdout --rules > custom.txt

# Combine multiple lists
cat list1.txt list2.txt list3.txt > combined.txt
```

## Configuration Options

### Threads/Fork
- **Default**: 4
- **Recommended**: Number of CPU cores
- **High-end**: 8-16 for fast cracking

### Rules
- **none**: No transformations
- **best64**: Best 64 rules (recommended)
- **single**: For single crack mode
- **wordlist**: Standard wordlist rules
- **extra**: Additional transformations
- **jumbo**: All available rules
- **KoreLogic**: Advanced rules

### Format Detection
- **auto**: Automatically detect hash type
- **specific**: Select exact format for faster cracking

## Performance Tips

1. **Use specific formats**: Auto-detection is slower
2. **Start with best64 rules**: Good balance of coverage/speed
3. **Adjust threads**: Match your CPU core count
4. **Use incremental wisely**: Can take very long time
5. **Session names**: Use descriptive names for multiple jobs
6. **Monitor statistics**: Check progress regularly

## Example Workflows

### Crack Linux Passwords
```bash
# 1. Extract hashes
sudo unshadow /etc/passwd /etc/shadow > linux_hashes.txt

# 2. In GUI:
#    - Load linux_hashes.txt
#    - Mode: Wordlist
#    - Wordlist: rockyou.txt
#    - Rules: best64
#    - Format: auto or sha512crypt
```

### Crack Windows NTLM
```bash
# 1. Extract hashes (using other tools)
# 2. In GUI:
#    - Load windows_hashes.txt
#    - Mode: Wordlist
#    - Wordlist: rockyou.txt
#    - Format: NTLM
#    - Rules: best64
```

### Crack ZIP File
```bash
# 1. Extract hash
zip2john encrypted.zip > zip_hash.txt

# 2. In GUI:
#    - Load zip_hash.txt
#    - Mode: Wordlist
#    - Wordlist: rockyou.txt
#    - Format: zip
```

### Crack WiFi WPA/WPA2
```bash
# 1. Extract from .cap file
aircrack-ng -J wifi wifi.cap
hccap2john wifi.hccap > wifi_hash.txt

# 2. In GUI:
#    - Load wifi_hash.txt
#    - Mode: Wordlist
#    - Wordlist: rockyou.txt
#    - Format: wpapsk
```

## Troubleshooting

### John not found
```bash
sudo apt-get install john
```

### No password cracked
- Verify hash format is correct
- Try different wordlists
- Use incremental mode for brute force
- Check if hash is salted

### Slow performance
- Use specific format instead of auto
- Reduce number of threads
- Use smaller wordlists first
- Check system resources

### Session won't restore
- Verify session name is correct
- Check ~/.john/ directory for session files
- Ensure original hash file is accessible

## Advanced Features

### Custom Rules
Create custom rules in john.conf:
```
[List.Rules:MyRules]
Az"[0-9]"
```

### Using Multiple Wordlists
```bash
# Combine lists
cat list1.txt list2.txt > combined.txt
```

### Benchmarking
```bash
john --test
```

## Security Best Practices

1. **Authorization**: Get written permission before testing
2. **Scope**: Only test systems you're authorized to access
3. **Documentation**: Keep detailed logs
4. **Confidentiality**: Protect cracked credentials
5. **Reporting**: Report findings through proper channels
6. **Ethical Use**: Never use for malicious purposes

## Output Files

John creates several files:
- **~/.john/john.pot**: Cracked passwords database
- **~/.john/john.rec**: Session recovery file
- **~/.john/john.log**: Activity log

## License

MIT License - See LICENSE file for details

## Disclaimer

This tool is provided for educational and authorized security testing purposes only. The creators are not responsible for any misuse or damage caused by this program. Users must comply with all applicable laws and regulations.

## Support & Resources

- John the Ripper Documentation: https://www.openwall.com/john/doc/
- Password Cracking Community: https://hashcat.net/forum/
- Kali Linux Tools: https://www.kali.org/tools/john/

## Contributing

Contributions welcome! Submit pull requests or open issues on GitHub.

---

**Remember: Use responsibly. Knowledge is power - use it wisely and ethically.**
