# John the Ripper - Quick Reference Cheat Sheet

## Basic Commands (CLI Reference)

### Simple Cracking
```bash
# Auto-detect format
john hashes.txt

# Specific format
john --format=raw-md5 hashes.txt

# With wordlist
john --wordlist=rockyou.txt hashes.txt

# With rules
john --wordlist=rockyou.txt --rules=best64 hashes.txt
```

### Show Results
```bash
# Show cracked passwords
john --show hashes.txt

# Show with specific format
john --show --format=NTLM hashes.txt
```

### Session Management
```bash
# Save session
john --session=mysession hashes.txt

# Restore session
john --restore=mysession

# Show session status
john --status=mysession
```

### Advanced Options
```bash
# Incremental mode
john --incremental=Alnum hashes.txt

# Mask attack
john --mask='?u?l?l?l?d?d?d?d' hashes.txt

# Single crack mode
john --single hashes.txt

# External mode
john --external=MyMode hashes.txt
```

## Hash Extraction Commands

### Linux/Unix Passwords
```bash
# Combine passwd and shadow
unshadow /etc/passwd /etc/shadow > mypasswd.txt

# Crack it
john mypasswd.txt
```

### Windows Passwords
```bash
# From SAM dump
samdump2 SYSTEM SAM > sam_hashes.txt
john --format=NT sam_hashes.txt

# From pwdump
john --format=LM pwdump_output.txt
```

### Application Hashes

#### ZIP Files
```bash
zip2john encrypted.zip > zip_hash.txt
john zip_hash.txt
```

#### RAR Files
```bash
rar2john encrypted.rar > rar_hash.txt
john rar_hash.txt
```

#### PDF Files
```bash
pdf2john encrypted.pdf > pdf_hash.txt
john pdf_hash.txt
```

#### SSH Keys
```bash
ssh2john id_rsa > ssh_hash.txt
john ssh_hash.txt
```

#### Office Documents
```bash
office2john document.docx > office_hash.txt
john office_hash.txt
```

#### KeePass
```bash
keepass2john database.kdbx > keepass_hash.txt
john keepass_hash.txt
```

### Network Protocol Hashes

#### WiFi WPA/WPA2
```bash
# From .cap file
hccap2john capture.hccap > wifi_hash.txt
john --format=wpapsk wifi_hash.txt
```

#### Kerberos
```bash
# From kirbi file
kirbi2john ticket.kirbi > krb_hash.txt
john --format=krb5tgs krb_hash.txt
```

## Hash Format Examples

### Raw Hashes
```
# MD5
098f6bcd4621d373cade4e832627b4f6

# SHA-1
a94a8fe5ccb19ba61c4c0873d391e987982fbbd3

# SHA-256
5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8

# SHA-512
b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86
```

### Salted Hashes
```
# MD5(Unix)
$1$salt$hash

# SHA-256(Unix)
$5$salt$hash

# SHA-512(Unix)
$6$salt$hash

# bcrypt
$2a$10$salt+hash

# NTLM (Windows)
user:1001:LMhash:NThash:::
```

## Common Wordlists

### Kali Linux Default Locations
```
/usr/share/wordlists/rockyou.txt
/usr/share/wordlists/fasttrack.txt
/usr/share/wordlists/metasploit/
/usr/share/seclists/Passwords/
```

### Download Popular Lists
```bash
# SecLists
git clone https://github.com/danielmiessler/SecLists.git

# CeWL (generate from website)
cewl https://example.com -m 6 -w custom.txt
```

## Mask Attack Patterns

### Mask Charset
```
?l = lowercase (a-z)
?u = uppercase (A-Z)
?d = digit (0-9)
?s = special (!@#$%...)
?a = all printable
?b = binary (0x00-0xFF)
```

### Common Patterns
```bash
# Password1234
john --mask='?u?l?l?l?l?l?l?l?d?d?d?d' hashes.txt

# Pass123!
john --mask='?u?l?l?l?d?d?d?s' hashes.txt

# Admin2024
john --mask='Admin?d?d?d?d' hashes.txt

# 4-digit PIN
john --mask='?d?d?d?d' hashes.txt

# Phone number (US)
john --mask='?d?d?d-?d?d?d-?d?d?d?d' hashes.txt
```

## Rules

### Built-in Rules
```
none        - No transformations
single      - For single crack mode
wordlist    - Standard wordlist rules
extra       - Additional transformations
jumbo       - All available rules
best64      - Best 64 rules (recommended)
KoreLogic   - Advanced rules
all         - All rules combined
```

### Using Rules
```bash
john --wordlist=words.txt --rules=best64 hashes.txt
john --wordlist=words.txt --rules=KoreLogic hashes.txt
```

## Performance Tuning

### Multi-core Processing
```bash
# Use all cores
john --fork=8 hashes.txt

# Specific number
john --fork=4 hashes.txt
```

### Benchmarking
```bash
# Test all formats
john --test

# Test specific format
john --test --format=raw-md5

# Test with duration
john --test=5
```

### Format Listing
```bash
# List all formats
john --list=formats

# List subformats
john --list=subformats

# List encoding
john --list=encodings
```

## Configuration

### john.conf Location
```
/etc/john/john.conf
~/.john/john.conf
```

### Custom Incremental Mode
```ini
[Incremental:CustomASCII]
File = $JOHN/ascii.chr
MinLen = 6
MaxLen = 10
CharCount = 95
```

### Custom Rules
```ini
[List.Rules:MyRules]
# Append numbers
Az"[0-9]"
Az"[0-9][0-9]"

# Prepend year
A0"2024"

# Capitalize first letter
c

# Toggle case
t

# Duplicate word
d
```

## Useful Combinations

### Progressive Attack
```bash
# 1. Single mode (fastest)
john --single hashes.txt

# 2. Wordlist with rules
john --wordlist=rockyou.txt --rules=best64 hashes.txt

# 3. Incremental (slowest)
john --incremental=Alnum hashes.txt
```

### Targeted Attack
```bash
# Company passwords
john --wordlist=company_names.txt --rules=all hashes.txt

# Common patterns
john --mask='?u?l?l?l?l?d?d!' hashes.txt

# Keyboard patterns
john --wordlist=keyboard_patterns.txt hashes.txt
```

## Tips & Tricks

### 1. Optimize for Speed
```bash
# Use specific format
john --format=raw-md5 hashes.txt

# Limit password length
john --min-length=6 --max-length=12 hashes.txt
```

### 2. Save Progress
```bash
# Always use sessions for long jobs
john --session=longjob hashes.txt

# Check status anytime
john --status=longjob
```

### 3. Combine Multiple Techniques
```bash
# First: wordlist
john --wordlist=rockyou.txt --rules=best64 hashes.txt

# Then: mask for remaining
john --mask='?u?l?l?l?l?d?d?d?d' hashes.txt
```

### 4. Monitor Progress
```bash
# Press any key during cracking to see status
# Or check from another terminal
john --status=mysession

# Show ETA
watch -n 10 'john --status=mysession'
```

### 5. Manage Pot File
```bash
# Show all cracked (from pot file)
john --show hashes.txt

# Clear pot file (start fresh)
rm ~/.john/john.pot
```

## Common Issues & Solutions

### Issue: No password cracked
```bash
# Solution 1: Try different format
john --list=formats | grep -i suspected_type

# Solution 2: Use bigger wordlist
john --wordlist=/usr/share/wordlists/rockyou.txt

# Solution 3: Add rules
john --wordlist=wordlist.txt --rules=all
```

### Issue: Too slow
```bash
# Solution 1: Use specific format
john --format=raw-md5 instead of auto

# Solution 2: Increase threads
john --fork=8

# Solution 3: Reduce keyspace
john --min-length=8 --max-length=12
```

### Issue: Session interrupted
```bash
# Solution: Always can restore
john --restore=session_name
```

## Quick Reference Table

| Task | Command |
|------|---------|
| Basic crack | `john hashes.txt` |
| With wordlist | `john --wordlist=list.txt hashes.txt` |
| Show results | `john --show hashes.txt` |
| Incremental | `john --incremental hashes.txt` |
| Mask attack | `john --mask='?u?l?l?l?d?d' hashes.txt` |
| Multi-thread | `john --fork=4 hashes.txt` |
| Save session | `john --session=name hashes.txt` |
| Restore | `john --restore=name` |
| Status | `john --status=name` |
| List formats | `john --list=formats` |

## Emergency Commands

```bash
# Stop gracefully (saves session)
Ctrl+C

# Kill forcefully (may lose progress)
killall -9 john

# Resume after crash
john --restore

# Check what's running
ps aux | grep john
```

---

**Pro Tip**: Always start with fast attacks (single, wordlist+rules) before moving to slow attacks (incremental, large masks).
