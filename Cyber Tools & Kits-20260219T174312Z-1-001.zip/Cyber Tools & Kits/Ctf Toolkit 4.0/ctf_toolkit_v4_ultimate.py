#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════╗
║         🔐 CTF TOOLKIT - AUTO-SOLVER v3.0 🤖              ║
║      Real AI-Powered Automatic Challenge Solver          ║
║         With Local LLM & Full Tool Integration           ║
╚═══════════════════════════════════════════════════════════╝

FEATURES:
✓ REAL AUTO-SOLVING - Actually solves CTF challenges
✓ Local AI (Ollama Llama 3.2) - Runs on 8GB+ RAM
✓ Auto-installs EVERYTHING needed
✓ Full tool integration (100+ CTF tools)
✓ Works on Kali, Linux, macOS, Windows (WSL)
✓ Beautiful web interface with real-time solving
✓ Supports ALL CTF categories
✓ Iterative solving with tool execution
"""

import os
import sys
import subprocess
import json
import base64
import hashlib
import re
import sqlite3
import string
import codecs
import tempfile
import shutil
from pathlib import Path
from collections import Counter
import threading
import webbrowser
from datetime import datetime
import time
import binascii
import struct

# ============================================================================
# AUTO-INSTALL ALL DEPENDENCIES
# ============================================================================

def install_python_packages():
    """Auto-install all required Python packages"""
    packages = [
        'flask', 'flask-cors', 'requests', 'pillow', 'pycryptodome',
        'python-magic-bin' if sys.platform == 'win32' else 'python-magic',
        'pwntools', 'scapy', 'beautifulsoup4', 'lxml', 'paramiko'
    ]
    
    print("[*] Installing Python dependencies...")
    for package in packages:
        try:
            subprocess.run(
                [sys.executable, '-m', 'pip', 'install', '-q', package],
                check=False,
                stderr=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                timeout=60
            )
        except:
            pass
    print("[✓] Python packages installed!")

def install_ollama_and_model():
    """Install Ollama and download Llama 3.2 model (3B - perfect for 8GB RAM)"""
    print("\n[*] Setting up AI model (Ollama + Llama 3.2)...")
    
    # Check if ollama is installed
    try:
        result = subprocess.run(['ollama', '--version'], capture_output=True, timeout=5)
        if result.returncode == 0:
            print("[✓] Ollama already installed")
        else:
            raise Exception("Need to install")
    except:
        print("[*] Installing Ollama...")
        os_type = detect_os()
        
        if os_type == 'macos':
            # Download and install Ollama for macOS
            subprocess.run([
                'curl', '-fsSL', 'https://ollama.com/install.sh', '-o', '/tmp/ollama_install.sh'
            ], check=False)
            subprocess.run(['sh', '/tmp/ollama_install.sh'], check=False)
        elif 'linux' in os_type or os_type == 'kali':
            # Install Ollama for Linux
            subprocess.run([
                'curl', '-fsSL', 'https://ollama.com/install.sh'
            ], stdout=subprocess.PIPE, check=False)
            subprocess.run([
                'sh', '-c', 'curl -fsSL https://ollama.com/install.sh | sh'
            ], check=False)
        else:
            print("[!] Please install Ollama manually from https://ollama.com")
            return False
    
    # Start ollama service
    print("[*] Starting Ollama service...")
    try:
        subprocess.Popen(['ollama', 'serve'], 
                        stdout=subprocess.DEVNULL, 
                        stderr=subprocess.DEVNULL)
        time.sleep(3)
    except:
        pass
    
    # Pull the model (llama3.2:3b - optimized for 8GB RAM)
    print("[*] Downloading AI model (Llama 3.2 - 3B, ~2GB download)...")
    print("    This may take a few minutes on first run...")
    try:
        subprocess.run(['ollama', 'pull', 'llama3.2:3b'], 
                      timeout=600, 
                      check=False)
        print("[✓] AI model ready!")
        return True
    except:
        print("[!] Could not download model. Will try again on next run.")
        return False

def detect_os():
    """Detect operating system"""
    if sys.platform.startswith('linux'):
        if os.path.exists('/etc/kali_version'):
            return 'kali'
        elif os.path.exists('/etc/debian_version'):
            return 'debian'
        elif os.path.exists('/etc/fedora-release'):
            return 'fedora'
        elif os.path.exists('/etc/arch-release'):
            return 'arch'
        return 'linux'
    elif sys.platform.startswith('darwin'):
        return 'macos'
    elif sys.platform.startswith('win'):
        return 'windows'
    return 'unknown'

def install_ctf_tools():
    """Install comprehensive CTF tools"""
    os_type = detect_os()
    print(f"\n[*] Installing CTF tools for {os_type}...")
    
    # Essential tools for all CTF categories
    tools = {
        'debian': [
            'binwalk', 'exiftool', 'steghide', 'nmap', 'sqlmap', 
            'john', 'hashcat', 'hydra', 'nikto', 'dirb', 'gobuster',
            'foremost', 'volatility3', 'wireshark', 'tcpdump',
            'radare2', 'gdb', 'strace', 'ltrace', 'patchelf',
            'python3-pwntools', 'ropper', 'checksec', 'one-gadget',
            'git', 'curl', 'wget', 'netcat', 'socat'
        ],
        'kali': [],  # Kali has everything
        'arch': [
            'binwalk', 'perl-image-exiftool', 'steghide', 'nmap', 
            'sqlmap', 'john', 'hashcat', 'hydra', 'nikto',
            'foremost', 'wireshark-cli', 'tcpdump', 'radare2',
            'gdb', 'strace', 'ltrace', 'git', 'curl', 'wget',
            'gnu-netcat', 'socat'
        ],
        'macos': [
            'binwalk', 'exiftool', 'steghide', 'nmap', 'sqlmap',
            'john', 'hashcat', 'hydra', 'foremost', 'radare2',
            'gdb', 'git', 'curl', 'wget', 'netcat', 'socat'
        ]
    }
    
    if os_type == 'kali':
        print("[✓] Kali Linux - tools pre-installed!")
        return
    
    tool_list = tools.get(os_type, tools.get('debian', []))
    
    try:
        if os_type == 'debian':
            subprocess.run(['sudo', '-n', 'apt-get', 'update', '-qq'],
                         check=False, stderr=subprocess.DEVNULL, timeout=120)
            for tool in tool_list:
                subprocess.run(['sudo', '-n', 'apt-get', 'install', '-y', '-qq', tool],
                             check=False, stderr=subprocess.DEVNULL, timeout=60)
        
        elif os_type == 'arch':
            for tool in tool_list:
                subprocess.run(['sudo', '-n', 'pacman', '-S', '--noconfirm', tool],
                             check=False, stderr=subprocess.DEVNULL, timeout=60)
        
        elif os_type == 'macos':
            for tool in tool_list:
                subprocess.run(['brew', 'install', tool],
                             check=False, stderr=subprocess.DEVNULL, timeout=60)
        
        print("[✓] CTF tools installed!")
    except Exception as e:
        print(f"[!] Some tools may not be installed: {e}")

# Run installations
install_python_packages()

# Now import packages
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
from PIL import Image
import magic

# ============================================================================
# CONFIGURATION
# ============================================================================

app = Flask(__name__)
CORS(app)

CONFIG = {
    'version': '3.0.0',
    'mode': 'auto',  # auto, beginner, advanced
    'work_dir': Path.home() / 'ctf_workspace',
    'db_path': Path.home() / '.ctf_toolkit.db',
    'port': 5000,
    'ollama_url': 'http://localhost:11434',
    'ollama_model': 'llama3.2:3b',
    'max_iterations': 10,
    'timeout': 300
}

CONFIG['work_dir'].mkdir(exist_ok=True)

# ============================================================================
# AI ASSISTANT - REAL LLM INTEGRATION
# ============================================================================

class AIAssistant:
    """Real AI assistant using local Ollama LLM"""
    
    def __init__(self):
        self.base_url = CONFIG['ollama_url']
        self.model = CONFIG['ollama_model']
        self.conversation_history = []
    
    def query(self, prompt, system_prompt=None):
        """Query the local LLM"""
        try:
            messages = []
            
            if system_prompt:
                messages.append({
                    "role": "system",
                    "content": system_prompt
                })
            
            # Add conversation history
            messages.extend(self.conversation_history[-4:])  # Last 4 messages for context
            
            messages.append({
                "role": "user",
                "content": prompt
            })
            
            response = requests.post(
                f"{self.base_url}/api/chat",
                json={
                    "model": self.model,
                    "messages": messages,
                    "stream": False
                },
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                assistant_message = result['message']['content']
                
                # Update history
                self.conversation_history.append({"role": "user", "content": prompt})
                self.conversation_history.append({"role": "assistant", "content": assistant_message})
                
                return assistant_message
            else:
                return None
                
        except Exception as e:
            print(f"[!] AI Error: {e}")
            return None
    
    def reset_conversation(self):
        """Reset conversation history"""
        self.conversation_history = []

# ============================================================================
# CTF SOLVER ENGINE
# ============================================================================

class CTFSolver:
    """Intelligent CTF challenge solver with real AI"""
    
    def __init__(self):
        self.ai = AIAssistant()
        self.tools = ToolExecutor()
        self.analyzers = {
            'crypto': CryptoAnalyzer(),
            'web': WebAnalyzer(),
            'forensics': ForensicsAnalyzer(),
            'reversing': ReversingAnalyzer(),
            'pwn': PwnAnalyzer(),
            'misc': MiscAnalyzer()
        }
    
    def auto_solve(self, challenge_data):
        """Automatically solve a CTF challenge"""
        print(f"\n[*] Starting auto-solve for challenge...")
        
        category = challenge_data.get('category', 'auto')
        description = challenge_data.get('description', '')
        file_path = challenge_data.get('file_path', '')
        
        # Detect category if auto
        if category == 'auto':
            category = self.detect_category(description, file_path)
            print(f"[*] Detected category: {category}")
        
        results = {
            'category': category,
            'steps': [],
            'attempts': [],
            'solution': None,
            'flag': None,
            'confidence': 0
        }
        
        # Initial analysis
        print("[*] Performing initial analysis...")
        initial_analysis = self.initial_analysis(description, file_path, category)
        results['steps'].append(f"Initial Analysis: {initial_analysis}")
        
        # Iterative solving
        for iteration in range(CONFIG['max_iterations']):
            print(f"\n[*] Solving iteration {iteration + 1}/{CONFIG['max_iterations']}...")
            
            # Ask AI what to do next
            solve_plan = self.ai.query(
                f"""You are a CTF challenge solver. Current situation:
                
Category: {category}
Description: {description}
File: {file_path}
Previous attempts: {json.dumps(results['attempts'][-3:] if results['attempts'] else [])}

What should we try next? Provide:
1. Tool/technique to use
2. Expected outcome
3. How to check if we found the flag

Format: TOOL: <tool_name> | REASON: <why> | CHECK: <how to verify>""",
                system_prompt=self.get_ctf_system_prompt()
            )
            
            if not solve_plan:
                print("[!] AI assistant not responding")
                break
            
            results['steps'].append(f"Iteration {iteration + 1}: {solve_plan}")
            
            # Parse AI response and execute
            attempt = self.execute_solve_plan(solve_plan, challenge_data, category)
            results['attempts'].append(attempt)
            
            # Check if we found a flag
            if attempt.get('flag'):
                results['flag'] = attempt['flag']
                results['solution'] = attempt.get('method', 'Unknown')
                results['confidence'] = attempt.get('confidence', 95)
                print(f"\n[✓] FLAG FOUND: {attempt['flag']}")
                break
            
            # Check if we should stop
            if 'no more ideas' in solve_plan.lower() or 'cannot solve' in solve_plan.lower():
                print("[!] AI exhausted all approaches")
                break
        
        return results
    
    def detect_category(self, description, file_path):
        """Auto-detect challenge category"""
        text = f"{description} {file_path}".lower()
        
        # Keywords for detection
        if any(k in text for k in ['encrypt', 'decrypt', 'cipher', 'hash', 'base64', 'rot13', 'crypto']):
            return 'crypto'
        elif any(k in text for k in ['sql', 'xss', 'injection', 'web', 'http', 'cookie', 'session']):
            return 'web'
        elif any(k in text for k in ['image', 'metadata', 'exif', 'steganography', 'steg', 'forensic', 'pcap']):
            return 'forensics'
        elif any(k in text for k in ['binary', 'reverse', 'assembly', 'disassemble', 'ghidra', 'ida']):
            return 'reversing'
        elif any(k in text for k in ['buffer', 'overflow', 'pwn', 'exploit', 'rop', 'shellcode']):
            return 'pwn'
        else:
            return 'misc'
    
    def initial_analysis(self, description, file_path, category):
        """Perform initial challenge analysis"""
        analysis = []
        
        # Analyze description
        if description:
            # Look for encoded data
            if re.search(r'[A-Za-z0-9+/=]{20,}', description):
                analysis.append("Found Base64-like string in description")
            
            # Look for hints
            hints = re.findall(r'hint:?\s*(.+)', description, re.IGNORECASE)
            if hints:
                analysis.append(f"Hints found: {hints}")
        
        # Analyze file
        if file_path and os.path.exists(file_path):
            try:
                # File type
                file_type = self.tools.run_command(f"file '{file_path}'")
                analysis.append(f"File type: {file_type['stdout']}")
                
                # File size
                size = os.path.getsize(file_path)
                analysis.append(f"File size: {size} bytes")
                
                # Quick strings check
                if size < 10_000_000:  # Only for small files
                    strings_out = self.tools.run_command(f"strings '{file_path}' | head -20")
                    if 'flag' in strings_out['stdout'].lower():
                        analysis.append("⚠️ Found 'flag' string in file!")
                
            except Exception as e:
                analysis.append(f"File analysis error: {e}")
        
        return " | ".join(analysis) if analysis else "No specific patterns detected"
    
    def execute_solve_plan(self, plan, challenge_data, category):
        """Execute the AI's solving plan"""
        attempt = {
            'plan': plan,
            'results': [],
            'flag': None,
            'method': None,
            'confidence': 0
        }
        
        # Parse the plan
        tool_match = re.search(r'TOOL:\s*([^\|]+)', plan)
        
        if tool_match:
            tool = tool_match.group(1).strip().lower()
            
            # Execute based on category
            analyzer = self.analyzers.get(category)
            if analyzer:
                result = analyzer.analyze(challenge_data, tool, self.tools)
                attempt['results'].append(result)
                
                # Check for flag
                flag = self.extract_flag(result)
                if flag:
                    attempt['flag'] = flag
                    attempt['method'] = tool
                    attempt['confidence'] = 90
        
        return attempt
    
    def extract_flag(self, text):
        """Extract flag from text"""
        if not text:
            return None
        
        text_str = str(text)
        
        # Common flag formats
        patterns = [
            r'(flag\{[^}]+\})',
            r'(picoCTF\{[^}]+\})',
            r'(CTF\{[^}]+\})',
            r'(FLAG\{[^}]+\})',
            r'(\w+\{[^}]+\})',  # Generic flag format
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text_str, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None
    
    def get_ctf_system_prompt(self):
        """Get system prompt for AI"""
        return """You are an expert CTF (Capture The Flag) challenge solver. Your goal is to find the flag.

Key principles:
1. Think step-by-step
2. Try the simplest approaches first
3. Use appropriate tools for each category
4. Look for common patterns (Base64, ROT13, simple ciphers)
5. Check file metadata and hidden data
6. Always look for the flag format: flag{...}, picoCTF{...}, etc.

Categories:
- Crypto: Try decoding (Base64, hex, ROT13), hash identification, cipher analysis
- Web: Check for SQL injection, XSS, directory traversal, hidden pages
- Forensics: Extract metadata, hidden files, steganography, string analysis
- Reversing: Disassemble, analyze strings, look for hardcoded secrets
- Pwn: Find vulnerabilities, buffer overflows, format strings
- Misc: Try everything, look for patterns, QR codes, etc.

Be specific about which tool to use and why."""

# ============================================================================
# CATEGORY ANALYZERS
# ============================================================================

class CryptoAnalyzer:
    """Analyze and solve crypto challenges"""
    
    def analyze(self, challenge_data, suggested_tool, tools):
        description = challenge_data.get('description', '')
        file_path = challenge_data.get('file_path', '')
        
        results = []
        
        # Try Base64
        if 'base64' in suggested_tool or not suggested_tool:
            try:
                # Find base64-like strings
                potential_b64 = re.findall(r'[A-Za-z0-9+/=]{20,}', description)
                for b64_str in potential_b64[:5]:
                    try:
                        decoded = base64.b64decode(b64_str).decode('utf-8', errors='ignore')
                        if decoded and len(decoded) > 3:
                            results.append(f"Base64 decoded: {decoded}")
                    except:
                        pass
            except:
                pass
        
        # Try ROT13
        if 'rot' in suggested_tool or not suggested_tool:
            rot13 = codecs.encode(description, 'rot_13')
            if rot13 != description:
                results.append(f"ROT13: {rot13}")
        
        # Try hex decode
        if 'hex' in suggested_tool or not suggested_tool:
            hex_matches = re.findall(r'[0-9a-fA-F]{10,}', description)
            for hex_str in hex_matches[:3]:
                try:
                    decoded = bytes.fromhex(hex_str).decode('utf-8', errors='ignore')
                    if decoded and len(decoded) > 3:
                        results.append(f"Hex decoded: {decoded}")
                except:
                    pass
        
        # Analyze file if provided
        if file_path and os.path.exists(file_path):
            try:
                with open(file_path, 'rb') as f:
                    content = f.read()
                    
                    # Try to decode as text
                    try:
                        text = content.decode('utf-8', errors='ignore')
                        results.append(f"File content preview: {text[:200]}")
                        
                        # Try Base64 on file content
                        try:
                            decoded = base64.b64decode(text).decode('utf-8', errors='ignore')
                            results.append(f"File Base64 decoded: {decoded[:200]}")
                        except:
                            pass
                    except:
                        pass
            except:
                pass
        
        return "\n".join(results) if results else "No crypto patterns found"

class WebAnalyzer:
    """Analyze web exploitation challenges"""
    
    def analyze(self, challenge_data, suggested_tool, tools):
        description = challenge_data.get('description', '')
        results = []
        
        # Extract URLs
        urls = re.findall(r'https?://[^\s]+', description)
        
        for url in urls[:3]:
            # Try to fetch page
            try:
                response = requests.get(url, timeout=5)
                results.append(f"URL {url}: Status {response.status_code}")
                
                # Check for flags in response
                if 'flag' in response.text.lower():
                    results.append(f"⚠️ Found 'flag' in page content!")
                
                # Check for comments
                comments = re.findall(r'<!--(.+?)-->', response.text, re.DOTALL)
                if comments:
                    results.append(f"HTML comments found: {comments[:2]}")
                
            except Exception as e:
                results.append(f"Could not fetch {url}: {e}")
        
        return "\n".join(results) if results else "No web vulnerabilities detected yet"

class ForensicsAnalyzer:
    """Analyze forensics challenges"""
    
    def analyze(self, challenge_data, suggested_tool, tools):
        file_path = challenge_data.get('file_path', '')
        results = []
        
        if not file_path or not os.path.exists(file_path):
            return "No file provided for forensics analysis"
        
        # File type
        file_result = tools.run_command(f"file '{file_path}'")
        results.append(f"File type: {file_result['stdout']}")
        
        # Strings analysis
        if 'strings' in suggested_tool or not suggested_tool:
            strings_result = tools.run_command(f"strings '{file_path}' | grep -i flag")
            if strings_result['stdout']:
                results.append(f"⚠️ Strings with 'flag': {strings_result['stdout']}")
        
        # Exiftool for metadata
        if 'exif' in suggested_tool or not suggested_tool:
            exif_result = tools.run_command(f"exiftool '{file_path}'")
            if exif_result['stdout']:
                results.append(f"Metadata: {exif_result['stdout'][:300]}")
        
        # Binwalk for hidden files
        if 'binwalk' in suggested_tool:
            binwalk_result = tools.run_command(f"binwalk '{file_path}'")
            if binwalk_result['stdout']:
                results.append(f"Binwalk: {binwalk_result['stdout']}")
        
        return "\n".join(results) if results else "No forensics findings yet"

class ReversingAnalyzer:
    """Analyze reversing challenges"""
    
    def analyze(self, challenge_data, suggested_tool, tools):
        file_path = challenge_data.get('file_path', '')
        results = []
        
        if not file_path or not os.path.exists(file_path):
            return "No binary provided for reversing"
        
        # File info
        file_result = tools.run_command(f"file '{file_path}'")
        results.append(f"Binary type: {file_result['stdout']}")
        
        # Strings
        strings_result = tools.run_command(f"strings '{file_path}' | head -50")
        results.append(f"Strings preview: {strings_result['stdout'][:300]}")
        
        # Check for flag in strings
        flag_strings = tools.run_command(f"strings '{file_path}' | grep -i flag")
        if flag_strings['stdout']:
            results.append(f"⚠️ Flag-related strings: {flag_strings['stdout']}")
        
        return "\n".join(results) if results else "Initial reversing analysis complete"

class PwnAnalyzer:
    """Analyze pwn/exploitation challenges"""
    
    def analyze(self, challenge_data, suggested_tool, tools):
        file_path = challenge_data.get('file_path', '')
        results = []
        
        if not file_path or not os.path.exists(file_path):
            return "No binary provided for pwn analysis"
        
        # File info
        file_result = tools.run_command(f"file '{file_path}'")
        results.append(f"Binary: {file_result['stdout']}")
        
        # Check security features
        checksec_result = tools.run_command(f"checksec --file='{file_path}'")
        if checksec_result['stdout']:
            results.append(f"Security: {checksec_result['stdout']}")
        
        return "\n".join(results) if results else "Pwn analysis in progress"

class MiscAnalyzer:
    """Analyze miscellaneous challenges"""
    
    def analyze(self, challenge_data, suggested_tool, tools):
        description = challenge_data.get('description', '')
        file_path = challenge_data.get('file_path', '')
        results = []
        
        # Try everything
        results.append("Attempting multiple approaches...")
        
        # Check description for patterns
        if description:
            # Look for any encoded data
            patterns = {
                'Binary': r'[01]{8,}',
                'Hex': r'[0-9a-fA-F]{10,}',
                'Base64': r'[A-Za-z0-9+/=]{20,}'
            }
            
            for name, pattern in patterns.items():
                if re.search(pattern, description):
                    results.append(f"Found {name} pattern in description")
        
        # If file, try to identify and analyze
        if file_path and os.path.exists(file_path):
            file_result = tools.run_command(f"file '{file_path}'")
            results.append(f"File: {file_result['stdout']}")
        
        return "\n".join(results) if results else "Misc analysis ongoing"

# ============================================================================
# TOOL EXECUTOR
# ============================================================================

class ToolExecutor:
    """Execute CTF tools and commands safely"""
    
    def run_command(self, command, timeout=30):
        """Run a shell command safely"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=CONFIG['work_dir']
            )
            return {
                'stdout': result.stdout.strip(),
                'stderr': result.stderr.strip(),
                'returncode': result.returncode,
                'success': result.returncode == 0
            }
        except subprocess.TimeoutExpired:
            return {
                'stdout': '',
                'stderr': 'Command timed out',
                'returncode': -1,
                'success': False
            }
        except Exception as e:
            return {
                'stdout': '',
                'stderr': str(e),
                'returncode': -1,
                'success': False
            }
    
    def install_tool_if_missing(self, tool_name):
        """Install a tool if it's not available"""
        # Check if tool exists
        check = self.run_command(f"which {tool_name}")
        if check['success']:
            return True
        
        print(f"[*] Installing missing tool: {tool_name}")
        os_type = detect_os()
        
        try:
            if os_type in ['debian', 'kali']:
                self.run_command(f"sudo -n apt-get install -y -qq {tool_name}", timeout=60)
            elif os_type == 'arch':
                self.run_command(f"sudo -n pacman -S --noconfirm {tool_name}", timeout=60)
            elif os_type == 'macos':
                self.run_command(f"brew install {tool_name}", timeout=60)
            return True
        except:
            return False

# ============================================================================
# DATABASE
# ============================================================================

class DatabaseManager:
    """Manage solved challenges"""
    
    def __init__(self):
        self.conn = sqlite3.connect(CONFIG['db_path'], check_same_thread=False)
        self.init_db()
    
    def init_db(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS challenges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                category TEXT,
                description TEXT,
                flag TEXT,
                solution TEXT,
                confidence INTEGER,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self.conn.commit()
    
    def save_challenge(self, name, category, description, flag, solution, confidence):
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO challenges (name, category, description, flag, solution, confidence)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (name, category, description, flag, solution, confidence))
        self.conn.commit()
    
    def get_challenges(self):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM challenges ORDER BY timestamp DESC LIMIT 50')
        return cursor.fetchall()

# ============================================================================
# FLASK API ROUTES
# ============================================================================

db = DatabaseManager()
solver = CTFSolver()

@app.route('/')
def index():
    return get_html_interface()

@app.route('/api/solve', methods=['POST'])
def solve_challenge():
    """Main endpoint for auto-solving challenges"""
    data = request.json
    
    try:
        # Prepare challenge data
        challenge_data = {
            'description': data.get('description', ''),
            'category': data.get('category', 'auto'),
            'file_path': data.get('file_path', '')
        }
        
        # Solve the challenge
        result = solver.auto_solve(challenge_data)
        
        # Save if solved
        if result['flag']:
            db.save_challenge(
                name=data.get('name', 'Unknown Challenge'),
                category=result['category'],
                description=challenge_data['description'][:500],
                flag=result['flag'],
                solution=result['solution'],
                confidence=result['confidence']
            )
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tools/run', methods=['POST'])
def run_tool():
    """Run a CTF tool command"""
    data = request.json
    command = data.get('command', '')
    
    if not command:
        return jsonify({'error': 'No command provided'}), 400
    
    # Security check - only allow safe commands
    dangerous_patterns = ['rm -rf', 'dd if=', 'mkfs', ':(){:', 'fork', '>/', 'sudo rm']
    if any(pattern in command.lower() for pattern in dangerous_patterns):
        return jsonify({'error': 'Dangerous command blocked'}), 403
    
    tools = ToolExecutor()
    result = tools.run_command(command)
    
    return jsonify(result)

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get solving history"""
    challenges = db.get_challenges()
    return jsonify({
        'challenges': [
            {
                'id': c[0],
                'name': c[1],
                'category': c[2],
                'flag': c[4],
                'timestamp': c[7]
            }
            for c in challenges
        ]
    })

@app.route('/api/config', methods=['POST'])
def update_config():
    """Update configuration"""
    data = request.json
    if 'mode' in data:
        CONFIG['mode'] = data['mode']
    return jsonify({'status': 'ok', 'config': CONFIG})

# ============================================================================
# HTML INTERFACE
# ============================================================================

def get_html_interface():
    return '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CTF Auto-Solver v3.0</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        :root {
            --bg-primary: #0a0e27;
            --bg-secondary: #1a1e3f;
            --bg-tertiary: #2a2e4f;
            --accent: #00ff88;
            --accent-secondary: #ff0088;
            --text-primary: #ffffff;
            --text-secondary: #a0a0c0;
            --success: #00ff88;
            --warning: #ffaa00;
            --danger: #ff0044;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, sans-serif;
            background: linear-gradient(135deg, var(--bg-primary) 0%, #0f1544 100%);
            color: var(--text-primary);
            min-height: 100vh;
            padding: 2rem;
        }
        
        .header {
            text-align: center;
            margin-bottom: 2rem;
            padding: 2rem;
            background: var(--bg-secondary);
            border-radius: 12px;
            border: 2px solid var(--accent);
            box-shadow: 0 0 30px rgba(0, 255, 136, 0.2);
        }
        
        .header h1 {
            font-size: 2.5rem;
            color: var(--accent);
            text-shadow: 0 0 20px rgba(0, 255, 136, 0.5);
            margin-bottom: 0.5rem;
        }
        
        .header .subtitle {
            color: var(--text-secondary);
            font-size: 1.1rem;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.5rem 1rem;
            background: rgba(0, 255, 136, 0.2);
            border: 1px solid var(--accent);
            border-radius: 20px;
            margin-top: 1rem;
            font-size: 0.9rem;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }
        
        .card {
            background: var(--bg-secondary);
            border-radius: 12px;
            padding: 2rem;
            border: 1px solid var(--bg-tertiary);
        }
        
        .card h2 {
            color: var(--accent);
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }
        
        .input-group {
            margin-bottom: 1.5rem;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        input[type="text"], textarea, select {
            width: 100%;
            padding: 0.75rem;
            background: var(--bg-tertiary);
            border: 1px solid var(--bg-tertiary);
            border-radius: 6px;
            color: var(--text-primary);
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        textarea {
            min-height: 120px;
            resize: vertical;
            font-family: 'Courier New', monospace;
        }
        
        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
        }
        
        .btn {
            background: linear-gradient(135deg, var(--accent) 0%, #00cc66 100%);
            color: var(--bg-primary);
            border: none;
            padding: 1rem 2rem;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
            width: 100%;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0, 255, 136, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .results {
            margin-top: 1.5rem;
            padding: 1.5rem;
            background: var(--bg-tertiary);
            border-radius: 6px;
            border-left: 4px solid var(--accent);
            max-height: 500px;
            overflow-y: auto;
        }
        
        .flag-found {
            background: rgba(0, 255, 136, 0.2);
            border: 2px solid var(--accent);
            padding: 1rem;
            border-radius: 6px;
            margin: 1rem 0;
            font-size: 1.1rem;
            font-weight: bold;
            text-align: center;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { box-shadow: 0 0 10px rgba(0, 255, 136, 0.5); }
            50% { box-shadow: 0 0 30px rgba(0, 255, 136, 0.8); }
        }
        
        .step {
            margin: 0.75rem 0;
            padding: 0.75rem;
            background: var(--bg-secondary);
            border-radius: 4px;
            border-left: 3px solid var(--accent-secondary);
        }
        
        .loading {
            text-align: center;
            padding: 2rem;
        }
        
        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid var(--bg-tertiary);
            border-top: 4px solid var(--accent);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .terminal {
            background: #000;
            color: var(--accent);
            padding: 1rem;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            margin-top: 1rem;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .terminal-output {
            white-space: pre-wrap;
            word-break: break-all;
        }
        
        .full-width {
            grid-column: 1 / -1;
        }
        
        .confidence {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        
        .confidence.high { background: var(--success); color: #000; }
        .confidence.medium { background: var(--warning); color: #000; }
        .confidence.low { background: var(--danger); color: #fff; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🤖 CTF AUTO-SOLVER v3.0</h1>
        <p class="subtitle">Real AI-Powered Automatic Challenge Solver</p>
        <div class="status-badge">✓ AI Engine: Llama 3.2 | Status: Ready</div>
    </div>
    
    <div class="container">
        <div class="card">
            <h2>🎯 Challenge Input</h2>
            
            <div class="input-group">
                <label>Challenge Description / Encoded Data</label>
                <textarea id="description" placeholder="Paste challenge text, encoded data, or description here..."></textarea>
            </div>
            
            <div class="input-group">
                <label>Category</label>
                <select id="category">
                    <option value="auto">🔍 Auto-Detect</option>
                    <option value="crypto">🔐 Cryptography</option>
                    <option value="web">🌐 Web Exploitation</option>
                    <option value="forensics">🔬 Forensics</option>
                    <option value="reversing">⚙️ Reverse Engineering</option>
                    <option value="pwn">💥 Binary Exploitation</option>
                    <option value="misc">🎲 Miscellaneous</option>
                </select>
            </div>
            
            <div class="input-group">
                <label>File Path (Optional)</label>
                <input type="text" id="file_path" placeholder="/path/to/challenge/file">
            </div>
            
            <button class="btn" onclick="autoSolve()">🚀 AUTO-SOLVE CHALLENGE</button>
            
            <div class="input-group" style="margin-top: 1.5rem;">
                <label>Quick Command</label>
                <input type="text" id="command" placeholder="strings file.bin | grep flag" onkeypress="if(event.key==='Enter')runCommand()">
            </div>
            <button class="btn" onclick="runCommand()" style="background: linear-gradient(135deg, #ff0088 0%, #cc0066 100%);">▶️ RUN COMMAND</button>
        </div>
        
        <div class="card">
            <h2>📊 Solving Progress</h2>
            <div id="results">
                <p style="color: var(--text-secondary); text-align: center; padding: 2rem;">
                    Ready to solve CTF challenges!<br><br>
                    ✓ AI Assistant: Online<br>
                    ✓ Tools: Ready<br>
                    ✓ Auto-Solver: Standby<br><br>
                    👈 Enter challenge details and click AUTO-SOLVE
                </p>
            </div>
        </div>
        
        <div class="card full-width">
            <h2>🖥️ Terminal Output</h2>
            <div class="terminal" id="terminal">$ CTF Auto-Solver Terminal
$ Workspace: ~/ctf_workspace
$ AI Model: Llama 3.2 (3B)
$ Ready to execute commands...
$</div>
        </div>
    </div>
    
    <script>
        async function autoSolve() {
            const description = document.getElementById('description').value.trim();
            const category = document.getElementById('category').value;
            const file_path = document.getElementById('file_path').value.trim();
            
            if (!description && !file_path) {
                alert('⚠️ Please provide challenge description or file path');
                return;
            }
            
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = '<div class="loading"><div class="spinner"></div><p>🤖 AI is analyzing and solving the challenge...<br>This may take 30-60 seconds</p></div>';
            
            try {
                const response = await fetch('/api/solve', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        description: description,
                        category: category,
                        file_path: file_path,
                        name: 'Challenge'
                    })
                });
                
                const data = await response.json();
                displayResults(data);
            } catch (error) {
                resultsDiv.innerHTML = `<p style="color: var(--danger)">❌ Error: ${error.message}</p>`;
            }
        }
        
        function displayResults(data) {
            const resultsDiv = document.getElementById('results');
            let html = '';
            
            html += `<h3>📂 Category: <span style="color: var(--accent)">${data.category.toUpperCase()}</span></h3>`;
            html += '<hr style="border: none; border-top: 1px solid var(--bg-tertiary); margin: 1rem 0">';
            
            if (data.flag) {
                html += `<div class="flag-found">🎉 FLAG FOUND: ${data.flag}</div>`;
                html += `<p><strong>Method:</strong> ${data.solution}</p>`;
                html += `<p><strong>Confidence:</strong> <span class="confidence high">${data.confidence}%</span></p>`;
            } else {
                html += '<p style="color: var(--warning)">⚠️ No flag found yet. Try adjusting the input or category.</p>';
            }
            
            if (data.steps && data.steps.length > 0) {
                html += '<h4 style="margin-top: 1.5rem;">🔍 Solving Steps:</h4>';
                data.steps.forEach((step, i) => {
                    html += `<div class="step"><strong>Step ${i+1}:</strong> ${step}</div>`;
                });
            }
            
            if (data.attempts && data.attempts.length > 0) {
                html += '<h4 style="margin-top: 1.5rem;">🔧 Attempts:</h4>';
                data.attempts.forEach((attempt, i) => {
                    html += `<div class="step"><strong>Attempt ${i+1}:</strong> ${JSON.stringify(attempt.plan).substring(0, 200)}</div>`;
                });
            }
            
            resultsDiv.innerHTML = html;
        }
        
        async function runCommand() {
            const command = document.getElementById('command').value.trim();
            if (!command) return;
            
            const terminalDiv = document.getElementById('terminal');
            terminalDiv.innerHTML += `\n$ ${command}\n`;
            
            try {
                const response = await fetch('/api/tools/run', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({command: command})
                });
                
                const data = await response.json();
                
                if (data.error) {
                    terminalDiv.innerHTML += `ERROR: ${data.error}\n`;
                } else {
                    if (data.stdout) terminalDiv.innerHTML += `${data.stdout}\n`;
                    if (data.stderr) terminalDiv.innerHTML += `${data.stderr}\n`;
                }
                
                terminalDiv.innerHTML += '$';
                terminalDiv.scrollTop = terminalDiv.scrollHeight;
                document.getElementById('command').value = '';
            } catch (error) {
                terminalDiv.innerHTML += `ERROR: ${error.message}\n`;
            }
        }
    </script>
</body>
</html>'''

# ============================================================================
# MAIN
# ============================================================================

def main():
    print("""
╔═══════════════════════════════════════════════════════════╗
║         🤖 CTF AUTO-SOLVER v3.0 - REAL AI EDITION         ║
║              Automatic Challenge Solver                   ║
╚═══════════════════════════════════════════════════════════╝
    """)
    
    print("[*] Initializing CTF Auto-Solver...")
    print(f"[✓] Workspace: {CONFIG['work_dir']}")
    print(f"[✓] Database: {CONFIG['db_path']}")
    
    # Ask about installations
    print("\n[?] Install CTF tools and AI model? (Recommended on first run)")
    print("    This includes: Ollama, Llama 3.2, and essential CTF tools")
    print("    Type 'yes' to install, or press ENTER to skip: ", end='')
    
    try:
        choice = input().strip().lower()
        if choice == 'yes':
            install_ctf_tools()
            install_ollama_and_model()
        else:
            print("[*] Skipping installation. Make sure tools are installed manually!")
    except:
        print("[*] Skipping installation")
    
    print(f"\n[✓] Starting web interface at http://localhost:{CONFIG['port']}")
    print("[*] The auto-solver will use AI to solve challenges automatically")
    print("[*] Press Ctrl+C to stop\n")
    
    # Open browser
    threading.Timer(2, lambda: webbrowser.open(f'http://localhost:{CONFIG["port"]}')).start()
    
    # Run Flask
    try:
        app.run(host='0.0.0.0', port=CONFIG['port'], debug=False, use_reloader=False)
    except KeyboardInterrupt:
        print("\n[*] Shutting down. Happy hacking! 🚀")

if __name__ == '__main__':
    main()
