#!/usr/bin/env python3
"""
John the Ripper GUI - A graphical interface for the John the Ripper password cracking tool
Author: Claude
License: MIT
"""

import subprocess
import sys
import os
import threading
import time
from pathlib import Path

# Auto-install dependencies
def install_dependencies():
    """Install required packages if not already installed"""
    required_packages = ['tkinter']
    
    # Check if john is installed - try multiple common locations
    john_paths = [
        'john',
        '/usr/bin/john',
        '/usr/sbin/john',
        '/usr/local/bin/john',
        'john-the-ripper'
    ]
    
    john_found = False
    for john_cmd in john_paths:
        try:
            result = subprocess.run([john_cmd, '--version'], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=5)
            if result.returncode == 0 or 'John the Ripper' in result.stdout + result.stderr:
                print("✓ John the Ripper is installed")
                print(f"Location: {john_cmd}")
                print(result.stdout or result.stderr)
                john_found = True
                break
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            continue
    
    if not john_found:
        print("⚠️  Warning: Could not verify John the Ripper installation")
        print("If you just installed it, it should work fine.")
        print("If you encounter issues, try:")
        print("  which john")
        print("  john --version")
        print("\nContinuing anyway...")
        time.sleep(2)

# Run dependency check
install_dependencies()

import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox

class JohnGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("John the Ripper Password Cracker")
        self.root.geometry("950x750")
        self.root.configure(bg='#2b2b2b')
        
        # Variables
        self.hash_file_var = tk.StringVar()
        self.wordlist_var = tk.StringVar()
        self.format_var = tk.StringVar(value='auto')
        self.mode_var = tk.StringVar(value='wordlist')
        self.rules_var = tk.StringVar(value='none')
        self.session_var = tk.StringVar(value='default')
        self.fork_var = tk.StringVar(value='4')
        self.show_var = tk.BooleanVar(value=False)
        self.incremental_var = tk.StringVar(value='ASCII')
        self.mask_var = tk.StringVar()
        
        self.is_running = False
        self.process = None
        self.status_thread = None
        
        self.create_widgets()
        
    def create_widgets(self):
        # Main container
        main_frame = tk.Frame(self.root, bg='#2b2b2b')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Title
        title = tk.Label(main_frame, text="🔓 John the Ripper Password Cracker", 
                        font=('Arial', 18, 'bold'), bg='#2b2b2b', fg='#00ff00')
        title.pack(pady=(0, 15))
        
        # Warning label
        warning = tk.Label(main_frame, 
                          text="⚠️  For authorized security testing and password recovery only",
                          font=('Arial', 9), bg='#2b2b2b', fg='#ff6b6b')
        warning.pack(pady=(0, 10))
        
        # Configuration Frame
        config_frame = tk.LabelFrame(main_frame, text="Configuration", 
                                    bg='#3b3b3b', fg='#ffffff', 
                                    font=('Arial', 10, 'bold'))
        config_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        # Hash file
        row = 0
        tk.Label(config_frame, text="Hash File:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.hash_file_var, width=50, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, columnspan=3, sticky='ew', padx=10, pady=5)
        tk.Button(config_frame, text="Browse", command=self.browse_hash_file,
                 bg='#5b5b5b', fg='#ffffff', relief=tk.FLAT).grid(
            row=row, column=4, padx=10, pady=5)
        
        # Mode selection
        row += 1
        tk.Label(config_frame, text="Attack Mode:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        
        mode_frame = tk.Frame(config_frame, bg='#3b3b3b')
        mode_frame.grid(row=row, column=1, columnspan=4, sticky='w', padx=10, pady=5)
        
        modes = [
            ('Wordlist', 'wordlist'),
            ('Incremental', 'incremental'),
            ('Single Crack', 'single'),
            ('Mask Attack', 'mask')
        ]
        
        for text, value in modes:
            tk.Radiobutton(mode_frame, text=text, variable=self.mode_var, 
                          value=value, bg='#3b3b3b', fg='#ffffff',
                          selectcolor='#4b4b4b', activebackground='#3b3b3b',
                          activeforeground='#ffffff', command=self.update_mode_options).pack(side=tk.LEFT, padx=5)
        
        # Wordlist (for wordlist mode)
        row += 1
        self.wordlist_label = tk.Label(config_frame, text="Wordlist File:", bg='#3b3b3b', fg='#ffffff')
        self.wordlist_label.grid(row=row, column=0, sticky='w', padx=10, pady=5)
        self.wordlist_entry = tk.Entry(config_frame, textvariable=self.wordlist_var, width=50, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white')
        self.wordlist_entry.grid(row=row, column=1, columnspan=3, sticky='ew', padx=10, pady=5)
        self.wordlist_button = tk.Button(config_frame, text="Browse", command=self.browse_wordlist,
                 bg='#5b5b5b', fg='#ffffff', relief=tk.FLAT)
        self.wordlist_button.grid(row=row, column=4, padx=10, pady=5)
        
        # Incremental mode (for incremental)
        row += 1
        self.incremental_label = tk.Label(config_frame, text="Incremental Mode:", bg='#3b3b3b', fg='#ffffff')
        self.incremental_label.grid(row=row, column=0, sticky='w', padx=10, pady=5)
        incremental_modes = ['ASCII', 'Alnum', 'Alpha', 'Digits', 'LowerNum', 'UpperNum']
        self.incremental_combo = ttk.Combobox(config_frame, textvariable=self.incremental_var, 
                                             values=incremental_modes, width=15, state='readonly')
        self.incremental_combo.grid(row=row, column=1, sticky='w', padx=10, pady=5)
        
        # Mask (for mask attack)
        self.mask_label = tk.Label(config_frame, text="Mask Pattern:", bg='#3b3b3b', fg='#ffffff')
        self.mask_label.grid(row=row, column=2, sticky='w', padx=10, pady=5)
        self.mask_entry = tk.Entry(config_frame, textvariable=self.mask_var, width=20, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white')
        self.mask_entry.grid(row=row, column=3, sticky='w', padx=10, pady=5)
        
        # Format
        row += 1
        tk.Label(config_frame, text="Hash Format:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        
        formats = ['auto', 'md5', 'sha1', 'sha256', 'sha512', 'des', 'md5crypt', 
                  'bcrypt', 'LM', 'NTLM', 'raw-md5', 'raw-sha1', 'raw-sha256', 
                  'zip', 'rar', 'pdf', 'krb5', 'mssql', 'mysql-sha1']
        format_combo = ttk.Combobox(config_frame, textvariable=self.format_var, 
                                   values=formats, width=15, state='readonly')
        format_combo.grid(row=row, column=1, sticky='w', padx=10, pady=5)
        
        # Rules
        tk.Label(config_frame, text="Rules:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=2, sticky='w', padx=10, pady=5)
        
        rules = ['none', 'best64', 'single', 'wordlist', 'extra', 'jumbo', 'KoreLogic', 'all']
        rules_combo = ttk.Combobox(config_frame, textvariable=self.rules_var, 
                                  values=rules, width=15, state='readonly')
        rules_combo.grid(row=row, column=3, sticky='w', padx=10, pady=5)
        
        # Session name
        row += 1
        tk.Label(config_frame, text="Session Name:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.session_var, width=20, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, sticky='w', padx=10, pady=5)
        
        # Fork (threads)
        tk.Label(config_frame, text="Fork/Threads:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=2, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.fork_var, width=10, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=3, sticky='w', padx=10, pady=5)
        
        # Show cracked passwords
        row += 1
        tk.Checkbutton(config_frame, text="Show cracked passwords after completion", 
                      variable=self.show_var,
                      bg='#3b3b3b', fg='#ffffff', selectcolor='#4b4b4b',
                      activebackground='#3b3b3b', activeforeground='#ffffff').grid(
            row=row, column=0, columnspan=3, sticky='w', padx=10, pady=5)
        
        config_frame.columnconfigure(1, weight=1)
        config_frame.columnconfigure(3, weight=1)
        
        # Quick Actions Frame
        quick_frame = tk.LabelFrame(main_frame, text="Quick Actions", 
                                   bg='#3b3b3b', fg='#ffffff', 
                                   font=('Arial', 10, 'bold'))
        quick_frame.pack(fill=tk.X, padx=5, pady=5)
        
        quick_button_frame = tk.Frame(quick_frame, bg='#3b3b3b')
        quick_button_frame.pack(pady=5)
        
        tk.Button(quick_button_frame, text="📊 Show Statistics", 
                 command=self.show_statistics,
                 bg='#5b5b5b', fg='#ffffff', 
                 font=('Arial', 9),
                 relief=tk.FLAT, padx=10, pady=5,
                 cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        tk.Button(quick_button_frame, text="🔍 Show Cracked", 
                 command=self.show_cracked,
                 bg='#5b5b5b', fg='#ffffff', 
                 font=('Arial', 9),
                 relief=tk.FLAT, padx=10, pady=5,
                 cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        tk.Button(quick_button_frame, text="📋 List Formats", 
                 command=self.list_formats,
                 bg='#5b5b5b', fg='#ffffff', 
                 font=('Arial', 9),
                 relief=tk.FLAT, padx=10, pady=5,
                 cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        tk.Button(quick_button_frame, text="🔄 Restore Session", 
                 command=self.restore_session,
                 bg='#5b5b5b', fg='#ffffff', 
                 font=('Arial', 9),
                 relief=tk.FLAT, padx=10, pady=5,
                 cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        # Control buttons
        button_frame = tk.Frame(main_frame, bg='#2b2b2b')
        button_frame.pack(fill=tk.X, pady=10)
        
        self.start_button = tk.Button(button_frame, text="▶ Start Cracking", 
                                      command=self.start_cracking,
                                      bg='#00aa00', fg='#ffffff', 
                                      font=('Arial', 11, 'bold'),
                                      relief=tk.FLAT, padx=20, pady=8,
                                      cursor='hand2')
        self.start_button.pack(side=tk.LEFT, padx=5)
        
        self.stop_button = tk.Button(button_frame, text="⬛ Stop Cracking", 
                                     command=self.stop_cracking,
                                     bg='#aa0000', fg='#ffffff', 
                                     font=('Arial', 11, 'bold'),
                                     relief=tk.FLAT, padx=20, pady=8,
                                     cursor='hand2', state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="🗑 Clear Output", 
                 command=self.clear_output,
                 bg='#5b5b5b', fg='#ffffff', 
                 font=('Arial', 10),
                 relief=tk.FLAT, padx=15, pady=8,
                 cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        # Output frame
        output_frame = tk.LabelFrame(main_frame, text="Output", 
                                    bg='#3b3b3b', fg='#ffffff', 
                                    font=('Arial', 10, 'bold'))
        output_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.output_text = scrolledtext.ScrolledText(output_frame, 
                                                     bg='#1e1e1e', 
                                                     fg='#00ff00',
                                                     font=('Courier', 9),
                                                     insertbackground='white')
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = tk.Label(main_frame, textvariable=self.status_var, 
                            bg='#1e1e1e', fg='#00ff00', 
                            relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(fill=tk.X, pady=(5, 0))
        
        # Initial mode update
        self.update_mode_options()
    
    def update_mode_options(self):
        """Show/hide options based on selected mode"""
        mode = self.mode_var.get()
        
        # Hide all mode-specific widgets first
        self.wordlist_label.grid_remove()
        self.wordlist_entry.grid_remove()
        self.wordlist_button.grid_remove()
        self.incremental_label.grid_remove()
        self.incremental_combo.grid_remove()
        self.mask_label.grid_remove()
        self.mask_entry.grid_remove()
        
        # Show relevant widgets
        if mode == 'wordlist':
            self.wordlist_label.grid()
            self.wordlist_entry.grid()
            self.wordlist_button.grid()
        elif mode == 'incremental':
            self.incremental_label.grid()
            self.incremental_combo.grid()
        elif mode == 'mask':
            self.mask_label.grid()
            self.mask_entry.grid()
    
    def browse_hash_file(self):
        filename = filedialog.askopenfilename(
            title="Select Hash File",
            filetypes=[("Text files", "*.txt"), ("Hash files", "*.hash"), ("All files", "*.*")]
        )
        if filename:
            self.hash_file_var.set(filename)
    
    def browse_wordlist(self):
        filename = filedialog.askopenfilename(
            title="Select Wordlist",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.wordlist_var.set(filename)
    
    def clear_output(self):
        self.output_text.delete(1.0, tk.END)
    
    def log(self, message, color='#00ff00'):
        self.output_text.insert(tk.END, message + '\n')
        self.output_text.see(tk.END)
        self.output_text.update()
    
    def validate_inputs(self):
        if not self.hash_file_var.get():
            messagebox.showerror("Error", "Please select a hash file")
            return False
        
        if not os.path.exists(self.hash_file_var.get()):
            messagebox.showerror("Error", "Hash file does not exist")
            return False
        
        mode = self.mode_var.get()
        
        if mode == 'wordlist' and not self.wordlist_var.get():
            messagebox.showerror("Error", "Please select a wordlist for wordlist mode")
            return False
        
        if mode == 'wordlist' and not os.path.exists(self.wordlist_var.get()):
            messagebox.showerror("Error", "Wordlist file does not exist")
            return False
        
        if mode == 'mask' and not self.mask_var.get():
            messagebox.showerror("Error", "Please enter a mask pattern for mask attack")
            return False
        
        return True
    
    def build_command(self):
        cmd = ['john']
        
        # Add format if not auto
        if self.format_var.get() != 'auto':
            cmd.append(f'--format={self.format_var.get()}')
        
        # Add mode-specific options
        mode = self.mode_var.get()
        
        if mode == 'wordlist':
            cmd.append(f'--wordlist={self.wordlist_var.get()}')
            if self.rules_var.get() != 'none':
                cmd.append(f'--rules={self.rules_var.get()}')
        elif mode == 'incremental':
            cmd.append(f'--incremental={self.incremental_var.get()}')
        elif mode == 'single':
            cmd.append('--single')
        elif mode == 'mask':
            cmd.append(f'--mask={self.mask_var.get()}')
        
        # Add fork/threads
        if self.fork_var.get() and self.fork_var.get() != '1':
            cmd.append(f'--fork={self.fork_var.get()}')
        
        # Add session
        if self.session_var.get():
            cmd.append(f'--session={self.session_var.get()}')
        
        # Add hash file
        cmd.append(self.hash_file_var.get())
        
        return cmd
    
    def run_john(self, cmd):
        try:
            self.log(f"Command: {' '.join(cmd)}", '#ffff00')
            self.log("=" * 70)
            
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            for line in self.process.stdout:
                if not self.is_running:
                    break
                self.log(line.rstrip())
            
            self.process.wait()
            
            if self.process.returncode == 0 or self.process.returncode == 1:
                self.log("=" * 70)
                self.log("✓ Cracking session completed", '#00ff00')
                self.status_var.set("Session completed")
                
                # Show cracked passwords if option enabled
                if self.show_var.get():
                    time.sleep(1)
                    self.show_cracked()
            elif self.is_running:
                self.log("=" * 70)
                self.log("✗ Session finished with errors", '#ff6b6b')
                self.status_var.set("Session finished with errors")
            
        except Exception as e:
            self.log(f"Error: {str(e)}", '#ff6b6b')
            self.status_var.set(f"Error: {str(e)}")
        
        finally:
            self.is_running = False
            self.start_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)
    
    def start_cracking(self):
        if not self.validate_inputs():
            return
        
        self.is_running = True
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.status_var.set("Cracking in progress...")
        
        cmd = self.build_command()
        
        # Run in separate thread to keep GUI responsive
        thread = threading.Thread(target=self.run_john, args=(cmd,))
        thread.daemon = True
        thread.start()
    
    def stop_cracking(self):
        if self.process:
            self.is_running = False
            self.process.terminate()
            self.log("=" * 70)
            self.log("⬛ Cracking stopped by user", '#ffff00')
            self.status_var.set("Cracking stopped")
            self.start_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)
    
    def show_statistics(self):
        """Show cracking statistics"""
        try:
            session = self.session_var.get() or 'default'
            result = subprocess.run(
                ['john', f'--status={session}'],
                capture_output=True,
                text=True
            )
            
            self.log("=" * 70)
            self.log("📊 SESSION STATISTICS", '#ffff00')
            self.log("=" * 70)
            if result.stdout:
                self.log(result.stdout, '#00ffff')
            else:
                self.log("No statistics available for this session", '#ff6b6b')
            self.log("=" * 70)
            
        except Exception as e:
            self.log(f"Error showing statistics: {str(e)}", '#ff6b6b')
    
    def show_cracked(self):
        """Show cracked passwords"""
        try:
            hash_file = self.hash_file_var.get()
            if not hash_file:
                messagebox.showwarning("Warning", "No hash file selected")
                return
            
            result = subprocess.run(
                ['john', '--show', hash_file],
                capture_output=True,
                text=True
            )
            
            self.log("=" * 70)
            self.log("🔓 CRACKED PASSWORDS", '#ffff00')
            self.log("=" * 70)
            if result.stdout:
                self.log(result.stdout, '#00ff00')
            else:
                self.log("No passwords cracked yet", '#ff6b6b')
            self.log("=" * 70)
            
        except Exception as e:
            self.log(f"Error showing cracked passwords: {str(e)}", '#ff6b6b')
    
    def list_formats(self):
        """List all available hash formats"""
        try:
            result = subprocess.run(
                ['john', '--list=formats'],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            self.log("=" * 70)
            self.log("📋 AVAILABLE HASH FORMATS", '#ffff00')
            self.log("=" * 70)
            self.log(result.stdout, '#00ffff')
            self.log("=" * 70)
            
        except Exception as e:
            self.log(f"Error listing formats: {str(e)}", '#ff6b6b')
    
    def restore_session(self):
        """Restore a previous session"""
        try:
            session = self.session_var.get() or 'default'
            
            result = messagebox.askyesno(
                "Restore Session",
                f"Restore session '{session}'?\n\nThis will continue from where it left off."
            )
            
            if result:
                cmd = ['john', f'--restore={session}']
                
                self.log("=" * 70)
                self.log(f"🔄 Restoring session: {session}", '#ffff00')
                self.log("=" * 70)
                
                self.is_running = True
                self.start_button.config(state=tk.DISABLED)
                self.stop_button.config(state=tk.NORMAL)
                self.status_var.set("Restoring session...")
                
                thread = threading.Thread(target=self.run_john, args=(cmd,))
                thread.daemon = True
                thread.start()
                
        except Exception as e:
            self.log(f"Error restoring session: {str(e)}", '#ff6b6b')

def main():
    root = tk.Tk()
    app = JohnGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
