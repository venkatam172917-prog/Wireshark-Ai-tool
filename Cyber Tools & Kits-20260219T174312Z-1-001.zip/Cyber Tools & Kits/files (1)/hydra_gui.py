#!/usr/bin/env python3
"""
Hydra GUI - A graphical interface for the Hydra password bruteforcing tool
Author: Claude
License: MIT
"""

import subprocess
import sys
import os
import threading
from pathlib import Path

# Auto-install dependencies
def install_dependencies():
    """Install required packages if not already installed"""
    required_packages = ['tkinter']
    
    # Check if hydra is installed - try multiple common locations
    hydra_paths = [
        'hydra',
        '/usr/bin/hydra',
        '/usr/sbin/hydra',
        '/usr/local/bin/hydra'
    ]
    
    hydra_found = False
    for hydra_cmd in hydra_paths:
        try:
            result = subprocess.run([hydra_cmd, '-h'], 
                                  capture_output=True, 
                                  timeout=5)
            if result.returncode == 0 or result.returncode == 255:  # hydra -h returns 255
                print("✓ Hydra is installed")
                print(f"Location: {hydra_cmd}")
                hydra_found = True
                break
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            continue
    
    if not hydra_found:
        print("⚠️  Warning: Could not verify Hydra installation")
        print("If you just installed it, it should work fine.")
        print("If you encounter issues, try:")
        print("  which hydra")
        print("  hydra -h")
        print("\nContinuing anyway...")
        time.sleep(2)

# Run dependency check
install_dependencies()

import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox

class HydraGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Hydra Password Bruteforcer")
        self.root.geometry("900x700")
        self.root.configure(bg='#2b2b2b')
        
        # Variables
        self.target_var = tk.StringVar()
        self.protocol_var = tk.StringVar(value='ssh')
        self.port_var = tk.StringVar()
        self.username_var = tk.StringVar()
        self.password_var = tk.StringVar()
        self.userlist_var = tk.StringVar()
        self.passlist_var = tk.StringVar()
        self.threads_var = tk.StringVar(value='4')
        self.timeout_var = tk.StringVar(value='30')
        self.verbose_var = tk.BooleanVar(value=True)
        
        self.is_running = False
        self.process = None
        
        self.create_widgets()
        
    def create_widgets(self):
        # Main container
        main_frame = tk.Frame(self.root, bg='#2b2b2b')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Title
        title = tk.Label(main_frame, text="🔐 Hydra Password Bruteforcer", 
                        font=('Arial', 18, 'bold'), bg='#2b2b2b', fg='#00ff00')
        title.pack(pady=(0, 15))
        
        # Warning label
        warning = tk.Label(main_frame, 
                          text="⚠️  For authorized penetration testing only - Unauthorized use is illegal",
                          font=('Arial', 9), bg='#2b2b2b', fg='#ff6b6b')
        warning.pack(pady=(0, 10))
        
        # Configuration Frame
        config_frame = tk.LabelFrame(main_frame, text="Configuration", 
                                    bg='#3b3b3b', fg='#ffffff', 
                                    font=('Arial', 10, 'bold'))
        config_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        # Target settings
        row = 0
        tk.Label(config_frame, text="Target IP/Host:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.target_var, width=40, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, columnspan=2, sticky='ew', padx=10, pady=5)
        
        # Protocol
        row += 1
        tk.Label(config_frame, text="Protocol:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        protocols = ['ssh', 'ftp', 'http', 'https', 'http-get', 'http-post', 
                    'smtp', 'mysql', 'postgres', 'rdp', 'vnc', 'telnet']
        protocol_combo = ttk.Combobox(config_frame, textvariable=self.protocol_var, 
                                     values=protocols, width=15, state='readonly')
        protocol_combo.grid(row=row, column=1, sticky='w', padx=10, pady=5)
        
        # Port
        tk.Label(config_frame, text="Port (optional):", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=2, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.port_var, width=10, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=3, sticky='w', padx=10, pady=5)
        
        # Username
        row += 1
        tk.Label(config_frame, text="Username:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.username_var, width=20, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, sticky='w', padx=10, pady=5)
        
        # Password
        tk.Label(config_frame, text="Password:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=2, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.password_var, width=20, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=3, sticky='w', padx=10, pady=5)
        
        # User list
        row += 1
        tk.Label(config_frame, text="User List File:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.userlist_var, width=30, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, columnspan=2, sticky='ew', padx=10, pady=5)
        tk.Button(config_frame, text="Browse", command=self.browse_userlist,
                 bg='#5b5b5b', fg='#ffffff', relief=tk.FLAT).grid(
            row=row, column=3, padx=10, pady=5)
        
        # Password list
        row += 1
        tk.Label(config_frame, text="Password List File:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.passlist_var, width=30, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, columnspan=2, sticky='ew', padx=10, pady=5)
        tk.Button(config_frame, text="Browse", command=self.browse_passlist,
                 bg='#5b5b5b', fg='#ffffff', relief=tk.FLAT).grid(
            row=row, column=3, padx=10, pady=5)
        
        # Advanced options
        row += 1
        tk.Label(config_frame, text="Threads:", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=0, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.threads_var, width=10, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=1, sticky='w', padx=10, pady=5)
        
        tk.Label(config_frame, text="Timeout (s):", bg='#3b3b3b', fg='#ffffff').grid(
            row=row, column=2, sticky='w', padx=10, pady=5)
        tk.Entry(config_frame, textvariable=self.timeout_var, width=10, 
                bg='#4b4b4b', fg='#ffffff', insertbackground='white').grid(
            row=row, column=3, sticky='w', padx=10, pady=5)
        
        # Verbose option
        row += 1
        tk.Checkbutton(config_frame, text="Verbose output", variable=self.verbose_var,
                      bg='#3b3b3b', fg='#ffffff', selectcolor='#4b4b4b',
                      activebackground='#3b3b3b', activeforeground='#ffffff').grid(
            row=row, column=0, columnspan=2, sticky='w', padx=10, pady=5)
        
        config_frame.columnconfigure(1, weight=1)
        config_frame.columnconfigure(2, weight=1)
        
        # Control buttons
        button_frame = tk.Frame(main_frame, bg='#2b2b2b')
        button_frame.pack(fill=tk.X, pady=10)
        
        self.start_button = tk.Button(button_frame, text="▶ Start Attack", 
                                      command=self.start_attack,
                                      bg='#00aa00', fg='#ffffff', 
                                      font=('Arial', 11, 'bold'),
                                      relief=tk.FLAT, padx=20, pady=8,
                                      cursor='hand2')
        self.start_button.pack(side=tk.LEFT, padx=5)
        
        self.stop_button = tk.Button(button_frame, text="⬛ Stop Attack", 
                                     command=self.stop_attack,
                                     bg='#aa0000', fg='#ffffff', 
                                     font=('Arial', 11, 'bold'),
                                     relief=tk.FLAT, padx=20, pady=8,
                                     cursor='hand2', state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="🗑 Clear Output", 
                 command=self.clear_output,
                 bg='#5b5b5b', fg='#ffffff', 
                 font=('Arial', 10),
                 relief=tk.FLAT, padx=15, pady=8,
                 cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        # Output frame
        output_frame = tk.LabelFrame(main_frame, text="Output", 
                                    bg='#3b3b3b', fg='#ffffff', 
                                    font=('Arial', 10, 'bold'))
        output_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.output_text = scrolledtext.ScrolledText(output_frame, 
                                                     bg='#1e1e1e', 
                                                     fg='#00ff00',
                                                     font=('Courier', 9),
                                                     insertbackground='white')
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = tk.Label(main_frame, textvariable=self.status_var, 
                            bg='#1e1e1e', fg='#00ff00', 
                            relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(fill=tk.X, pady=(5, 0))
    
    def browse_userlist(self):
        filename = filedialog.askopenfilename(
            title="Select User List",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.userlist_var.set(filename)
    
    def browse_passlist(self):
        filename = filedialog.askopenfilename(
            title="Select Password List",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.passlist_var.set(filename)
    
    def clear_output(self):
        self.output_text.delete(1.0, tk.END)
    
    def log(self, message, color='#00ff00'):
        self.output_text.insert(tk.END, message + '\n')
        self.output_text.see(tk.END)
        self.output_text.update()
    
    def validate_inputs(self):
        if not self.target_var.get():
            messagebox.showerror("Error", "Please enter a target IP/Host")
            return False
        
        # Check if either single creds or lists are provided
        has_single_user = bool(self.username_var.get())
        has_single_pass = bool(self.password_var.get())
        has_userlist = bool(self.userlist_var.get())
        has_passlist = bool(self.passlist_var.get())
        
        if not (has_single_user or has_userlist):
            messagebox.showerror("Error", "Please provide either a username or user list")
            return False
        
        if not (has_single_pass or has_passlist):
            messagebox.showerror("Error", "Please provide either a password or password list")
            return False
        
        return True
    
    def build_command(self):
        cmd = ['hydra']
        
        # Add username/userlist
        if self.username_var.get():
            cmd.extend(['-l', self.username_var.get()])
        elif self.userlist_var.get():
            cmd.extend(['-L', self.userlist_var.get()])
        
        # Add password/passlist
        if self.password_var.get():
            cmd.extend(['-p', self.password_var.get()])
        elif self.passlist_var.get():
            cmd.extend(['-P', self.passlist_var.get()])
        
        # Add threads
        cmd.extend(['-t', self.threads_var.get()])
        
        # Add timeout
        cmd.extend(['-w', self.timeout_var.get()])
        
        # Add verbose
        if self.verbose_var.get():
            cmd.append('-V')
        
        # Add port if specified
        if self.port_var.get():
            cmd.extend(['-s', self.port_var.get()])
        
        # Add target and protocol
        cmd.append(self.target_var.get())
        cmd.append(self.protocol_var.get())
        
        return cmd
    
    def run_hydra(self, cmd):
        try:
            self.log(f"Command: {' '.join(cmd)}", '#ffff00')
            self.log("=" * 70)
            
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            for line in self.process.stdout:
                if not self.is_running:
                    break
                self.log(line.rstrip())
            
            self.process.wait()
            
            if self.process.returncode == 0:
                self.log("=" * 70)
                self.log("✓ Attack completed successfully", '#00ff00')
                self.status_var.set("Attack completed")
            elif self.is_running:
                self.log("=" * 70)
                self.log("✗ Attack finished with errors", '#ff6b6b')
                self.status_var.set("Attack finished with errors")
            
        except Exception as e:
            self.log(f"Error: {str(e)}", '#ff6b6b')
            self.status_var.set(f"Error: {str(e)}")
        
        finally:
            self.is_running = False
            self.start_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)
    
    def start_attack(self):
        if not self.validate_inputs():
            return
        
        self.is_running = True
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.status_var.set("Attack in progress...")
        
        cmd = self.build_command()
        
        # Run in separate thread to keep GUI responsive
        thread = threading.Thread(target=self.run_hydra, args=(cmd,))
        thread.daemon = True
        thread.start()
    
    def stop_attack(self):
        if self.process:
            self.is_running = False
            self.process.terminate()
            self.log("=" * 70)
            self.log("⬛ Attack stopped by user", '#ffff00')
            self.status_var.set("Attack stopped")
            self.start_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)

def main():
    root = tk.Tk()
    app = HydraGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
